const originalCache = 'path-personal-app-27c941f84c5697acd9083001';
const previousCache = originalCache + '-shell-v2';
const lastShellCache = originalCache + '-shell-v3';
const panelCache = originalCache + '-shell-v4';
const canvasCache = originalCache + '-shell-v5';
const iconsCache = originalCache + '-shell-v6';
const sharingPrevious = originalCache + '-shell-v8-sharing';
const preSharing = originalCache + '-shell-v7';
const cursorPrevious = originalCache + '-shell-v9-cursors';
const cacheName = originalCache + '-shell-v10-free-sharing';
self.addEventListener('message', event => {
  if (event.data === 'path-build') event.ports[0]?.postMessage('27c941f84c5697acd9083001');
});
const files = ["actions.css", "actions.mjs", "alpha-i18n.mjs", "alpha-model.mjs", "alpha-ui.mjs", "alpha.css", "app.mjs", "assets/marcus.svg", "assets/panel-noise.svg", "assets/sport/catalogue.json", "assets/sport/svg/arms/alternating-dumbbell-curl.svg", "assets/sport/svg/arms/barbell-biceps-curl.svg", "assets/sport/svg/arms/cable-biceps-curl.svg", "assets/sport/svg/arms/concentration-curl.svg", "assets/sport/svg/arms/dumbbell-triceps-kickback.svg", "assets/sport/svg/arms/hammer-curl.svg", "assets/sport/svg/arms/incline-dumbbell-curl.svg", "assets/sport/svg/arms/lying-ez-bar-triceps-extension.svg", "assets/sport/svg/arms/overhead-dumbbell-triceps-extension.svg", "assets/sport/svg/arms/parallel-bar-dip.svg", "assets/sport/svg/arms/preacher-curl.svg", "assets/sport/svg/arms/rope-triceps-pushdown.svg", "assets/sport/svg/back/back-extension.svg", "assets/sport/svg/back/bent-over-barbell-row.svg", "assets/sport/svg/back/chest-supported-dumbbell-row.svg", "assets/sport/svg/back/chin-up.svg", "assets/sport/svg/back/inverted-row.svg", "assets/sport/svg/back/lat-pulldown.svg", "assets/sport/svg/back/one-arm-dumbbell-row.svg", "assets/sport/svg/back/pull-up.svg", "assets/sport/svg/back/seated-cable-row.svg", "assets/sport/svg/back/straight-arm-cable-pulldown.svg", "assets/sport/svg/back/superman.svg", "assets/sport/svg/back/t-bar-row.svg", "assets/sport/svg/chest/barbell-bench-press.svg", "assets/sport/svg/chest/decline-push-up.svg", "assets/sport/svg/chest/diamond-push-up.svg", "assets/sport/svg/chest/dumbbell-chest-fly.svg", "assets/sport/svg/chest/dumbbell-floor-press.svg", "assets/sport/svg/chest/incline-dumbbell-press.svg", "assets/sport/svg/chest/incline-push-up.svg", "assets/sport/svg/chest/knee-push-up.svg", "assets/sport/svg/chest/pec-deck-fly.svg", "assets/sport/svg/chest/push-up.svg", "assets/sport/svg/chest/standing-cable-chest-fly.svg", "assets/sport/svg/chest/wide-push-up.svg", "assets/sport/svg/conditioning/box-jump.svg", "assets/sport/svg/conditioning/burpee.svg", "assets/sport/svg/conditioning/butt-kicks.svg", "assets/sport/svg/conditioning/high-knees.svg", "assets/sport/svg/conditioning/jump-rope.svg", "assets/sport/svg/conditioning/jumping-jack.svg", "assets/sport/svg/conditioning/mountain-climber.svg", "assets/sport/svg/conditioning/rowing-machine.svg", "assets/sport/svg/conditioning/skater-jump.svg", "assets/sport/svg/conditioning/squat-jump.svg", "assets/sport/svg/conditioning/stationary-bike.svg", "assets/sport/svg/conditioning/treadmill-running.svg", "assets/sport/svg/core-flexion/bicycle-crunch.svg", "assets/sport/svg/core-flexion/crunch.svg", "assets/sport/svg/core-flexion/dumbbell-side-bend.svg", "assets/sport/svg/core-flexion/hanging-knee-raise.svg", "assets/sport/svg/core-flexion/hanging-leg-raise.svg", "assets/sport/svg/core-flexion/kneeling-cable-crunch.svg", "assets/sport/svg/core-flexion/lying-leg-raise.svg", "assets/sport/svg/core-flexion/reverse-crunch.svg", "assets/sport/svg/core-flexion/russian-twist.svg", "assets/sport/svg/core-flexion/sit-up.svg", "assets/sport/svg/core-flexion/standing-cable-woodchop.svg", "assets/sport/svg/core-flexion/v-up.svg", "assets/sport/svg/core-stability/ab-wheel-rollout.svg", "assets/sport/svg/core-stability/bear-plank.svg", "assets/sport/svg/core-stability/bird-dog.svg", "assets/sport/svg/core-stability/dead-bug.svg", "assets/sport/svg/core-stability/farmers-walk.svg", "assets/sport/svg/core-stability/forearm-plank.svg", "assets/sport/svg/core-stability/high-plank.svg", "assets/sport/svg/core-stability/hollow-body-hold.svg", "assets/sport/svg/core-stability/pallof-press.svg", "assets/sport/svg/core-stability/reverse-plank.svg", "assets/sport/svg/core-stability/side-plank.svg", "assets/sport/svg/core-stability/suitcase-carry.svg", "assets/sport/svg/functional-strength/backward-sled-drag.svg", "assets/sport/svg/functional-strength/barbell-push-press.svg", "assets/sport/svg/functional-strength/battle-rope-waves.svg", "assets/sport/svg/functional-strength/dumbbell-renegade-row.svg", "assets/sport/svg/functional-strength/dumbbell-thruster.svg", "assets/sport/svg/functional-strength/kettlebell-clean.svg", "assets/sport/svg/functional-strength/kettlebell-snatch.svg", "assets/sport/svg/functional-strength/medicine-ball-slam.svg", "assets/sport/svg/functional-strength/sandbag-bear-hug-carry.svg", "assets/sport/svg/functional-strength/sled-push.svg", "assets/sport/svg/functional-strength/turkish-get-up.svg", "assets/sport/svg/functional-strength/wall-ball-throw.svg", "assets/sport/svg/mobility-lower/butterfly-stretch.svg", "assets/sport/svg/mobility-lower/cossack-squat.svg", "assets/sport/svg/mobility-lower/deep-squat-hold.svg", "assets/sport/svg/mobility-lower/frog-stretch.svg", "assets/sport/svg/mobility-lower/half-kneeling-hip-flexor-stretch.svg", "assets/sport/svg/mobility-lower/knee-to-wall-ankle-mobilization.svg", "assets/sport/svg/mobility-lower/pigeon-stretch.svg", "assets/sport/svg/mobility-lower/seated-90-90-hip-stretch.svg", "assets/sport/svg/mobility-lower/standing-quadriceps-stretch.svg", "assets/sport/svg/mobility-lower/supine-figure-four-stretch.svg", "assets/sport/svg/mobility-lower/supine-strap-hamstring-stretch.svg", "assets/sport/svg/mobility-lower/wall-calf-stretch.svg", "assets/sport/svg/mobility-upper/cat-stretch.svg", "assets/sport/svg/mobility-upper/cross-body-shoulder-stretch.svg", "assets/sport/svg/mobility-upper/doorway-chest-stretch.svg", "assets/sport/svg/mobility-upper/dowel-shoulder-pass-through.svg", "assets/sport/svg/mobility-upper/kneeling-bench-lat-stretch.svg", "assets/sport/svg/mobility-upper/lateral-neck-stretch.svg", "assets/sport/svg/mobility-upper/open-book-rotation.svg", "assets/sport/svg/mobility-upper/overhead-triceps-stretch.svg", "assets/sport/svg/mobility-upper/quadruped-wrist-stretch.svg", "assets/sport/svg/mobility-upper/sphinx-stretch.svg", "assets/sport/svg/mobility-upper/thread-the-needle.svg", "assets/sport/svg/mobility-upper/wall-angel.svg", "assets/sport/svg/posterior-chain/barbell-good-morning.svg", "assets/sport/svg/posterior-chain/barbell-hip-thrust.svg", "assets/sport/svg/posterior-chain/cable-glute-kickback.svg", "assets/sport/svg/posterior-chain/conventional-deadlift.svg", "assets/sport/svg/posterior-chain/glute-bridge.svg", "assets/sport/svg/posterior-chain/kettlebell-swing.svg", "assets/sport/svg/posterior-chain/lying-leg-curl.svg", "assets/sport/svg/posterior-chain/romanian-deadlift.svg", "assets/sport/svg/posterior-chain/seated-calf-raise.svg", "assets/sport/svg/posterior-chain/single-leg-romanian-deadlift.svg", "assets/sport/svg/posterior-chain/standing-calf-raise.svg", "assets/sport/svg/posterior-chain/sumo-deadlift.svg", "assets/sport/svg/quads/barbell-back-squat.svg", "assets/sport/svg/quads/barbell-front-squat.svg", "assets/sport/svg/quads/bodyweight-squat.svg", "assets/sport/svg/quads/bulgarian-split-squat.svg", "assets/sport/svg/quads/goblet-squat.svg", "assets/sport/svg/quads/lateral-lunge.svg", "assets/sport/svg/quads/leg-press.svg", "assets/sport/svg/quads/machine-leg-extension.svg", "assets/sport/svg/quads/reverse-lunge.svg", "assets/sport/svg/quads/split-squat.svg", "assets/sport/svg/quads/step-up.svg", "assets/sport/svg/quads/walking-lunge.svg", "assets/sport/svg/shoulders/arnold-press.svg", "assets/sport/svg/shoulders/barbell-upright-row.svg", "assets/sport/svg/shoulders/bent-over-reverse-fly.svg", "assets/sport/svg/shoulders/cable-face-pull.svg", "assets/sport/svg/shoulders/dumbbell-lateral-raise.svg", "assets/sport/svg/shoulders/dumbbell-shrug.svg", "assets/sport/svg/shoulders/half-kneeling-landmine-press.svg", "assets/sport/svg/shoulders/pike-push-up.svg", "assets/sport/svg/shoulders/plate-front-raise.svg", "assets/sport/svg/shoulders/seated-barbell-shoulder-press.svg", "assets/sport/svg/shoulders/single-arm-cable-lateral-raise.svg", "assets/sport/svg/shoulders/standing-dumbbell-shoulder-press.svg", "boot.mjs", "build-info.mjs", "calendar-cards.css", "calendar-completion.css", "calendar-completion.mjs", "calendar-impact.mjs", "calendar-model.mjs", "canvas-viewer.mjs", "date-utils.mjs", "desktop-adapter.mjs", "desktop-inspector.mjs", "desktop-test-controls.mjs", "desktop-test-i18n.mjs", "desktop-test-repository.mjs", "desktop-test.css", "domain/sport-body-map.js", "domain/sport-catalog.js", "domain/sport-core.js", "event-editor.mjs", "fonts/Manrope-Variable.ttf", "fonts/OFL.txt", "habit-icon.mjs", "habit-symbols.mjs", "i18n.mjs", "index.html", "media-store.mjs", "model.mjs", "navigation.css", "navigation.mjs", "numeric-fields.mjs", "numeric-picker.css", "numeric-picker.mjs", "numeric-values.mjs", "personal-client.mjs", "personal-model.mjs", "sync-merge.mjs", "personal.css", "phone-viewport.mjs", "shared-library.js", "sharing.css", "sport-i18n.mjs", "sport-model.mjs", "sport-ui.mjs", "sport.css", "styles.css", "task-selectors.mjs", "tasks.css", "typography.css"];
const appUrl = new URL(self.registration.scope);
const indexPath = new URL('index.html', appUrl).pathname;
// Cloudflare serves the index directly at the directory URL.
const urls = files.map(file => new URL(file === 'index.html' ? './' : file, appUrl));
const paths = new Set(urls.map(url => url.pathname));
const freshPaths = new Set(['personal-model.mjs', 'sync-merge.mjs', 'boot.mjs', 'navigation.mjs', 'navigation.css', 'app.mjs', 'alpha-ui.mjs', 'alpha-i18n.mjs', 'alpha-model.mjs', 'alpha.css', 'habit-symbols.mjs', 'canvas-viewer.mjs', 'styles.css', 'desktop-test-controls.mjs'].map(name => new URL(name, appUrl).pathname));

function shellRequest() {
  return new Request(appUrl, { redirect: 'error', cache: 'reload', credentials: 'omit' });
}

function documentResponse(response) {
  if (!response || response.status !== 200 || !response.headers.get('Content-Type')?.toLowerCase().startsWith('text/html')) return null;
  if (response.url && response.url !== appUrl.href) return null;
  // A new response for the public HTML starts with an empty redirect history.
  // Fetch already decoded the body, so its wire encoding and length no longer apply.
  const headers = new Headers(response.headers);
  headers.delete('Content-Encoding');
  headers.delete('Content-Length');
  return new Response(response.body, { headers });
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(cacheName);
    const shell = documentResponse(await fetch(shellRequest()));
    if (!shell) throw new Error('Expected the direct Path app document.');
    await cache.put(appUrl, shell.clone());
    const older = [];
    const existing = await caches.keys();
    for (const name of [cursorPrevious, sharingPrevious, preSharing, iconsCache, canvasCache, panelCache, lastShellCache, previousCache, originalCache]) {
      if (!existing.includes(name)) continue;
      const old = await caches.open(name);
      // A tab controlled by an older worker still needs the matching HTML and scripts.
      const key = name === originalCache ? indexPath : appUrl;
      const prior = documentResponse(await old.match(key));
      await old.put(key, prior || shell.clone());
      older.push(old);
    }
    const assets = urls.filter(url => url.href !== appUrl.href);
    for (let i = 0; i < assets.length; i += 4) {
      await Promise.all(assets.slice(i, i + 4).map(async url => {
        if (!freshPaths.has(url.pathname) && !['boot.mjs','app.mjs','shared-library.js','styles.css','sharing.css','alpha-ui.mjs'].includes(url.pathname.split('/').pop())) {
          for (const old of older) {
            const hit = await old.match(url);
            if (hit?.status === 200 && !hit.redirected) {
              await cache.put(url, hit);
              return;
            }
          }
        }
        try {
          await cache.add(new Request(url, { redirect: 'error', cache: 'reload' }));
        } catch (error) {
          // A missing exercise illustration can be filled on use.
          if (!url.pathname.includes('/assets/sport/svg/')) throw error;
        }
      }));
    }
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const name of await caches.keys()) {
    if (name.startsWith('path-personal-app-') && name !== cacheName) await caches.delete(name);
  }
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
  const path = url.pathname === indexPath ? appUrl.pathname : url.pathname;
  if (!paths.has(path)) return;
  event.respondWith((async () => {
    const cache = await caches.open(cacheName);
    const hit = await cache.match(path);
    if (path === appUrl.pathname) {
      const document = documentResponse(hit);
      if (document) return document;
      const fresh = documentResponse(await fetch(shellRequest()));
      if (!fresh) return Response.error();
      await cache.put(appUrl, fresh.clone()).catch(() => {});
      return fresh;
    }
    if (hit && !hit.redirected) return hit;
    const response = await fetch(event.request);
    if (response.status === 200 && !response.redirected) await cache.put(path, response.clone()).catch(() => {});
    return response;
  })());
});
