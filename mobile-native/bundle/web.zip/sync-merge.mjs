// Three-way merge shared by Path Mobile and the Windows full-sync engine.
export const collections = ['homeTasks', 'projects', 'events', 'eventSeries', 'habits',
  'programs', 'workouts', 'workoutRecords', 'skillTests', 'notes', 'canvases'];

export function equal(a, b) {
  if (a === b) return true;
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object' || Array.isArray(a) !== Array.isArray(b)) return false;
  const keys = Object.keys(a);
  return keys.length === Object.keys(b).length && keys.every(key => Object.hasOwn(b, key) && equal(a[key], b[key]));
}

const disputed = Symbol('disputed');
function agreed(base, local, remote) {
  if (equal(local, remote) || equal(base, local)) return remote;
  if (equal(base, remote)) return local;
  return disputed;
}
const without = (row, fields) => Object.fromEntries(Object.entries(row).filter(([key]) => !fields.includes(key)));
const logFields = ['values', 'checkIns', 'exceptions'];
const isMap = value => value && typeof value === 'object' && !Array.isArray(value);
const indexRows = rows => new Map(rows.map(row => [row.id, row]));

function dependencyIssues(tasks) {
  const byId = indexRows(tasks), stack = [], positions = new Map(), visited = new Set(), issues = new Set();
  function visit(id) {
    if (visited.has(id)) return;
    if (positions.has(id)) {
      for (const member of stack.slice(positions.get(id))) issues.add(member);
      return;
    }
    positions.set(id, stack.length);
    stack.push(id);
    const deps = byId.get(id).dependencies ?? [];
    if (!Array.isArray(deps)) issues.add(id);
    else for (const dep of deps) {
      if (byId.has(dep)) visit(dep);
      else { issues.add(id); issues.add(dep); }
    }
    stack.pop();
    positions.delete(id);
    visited.add(id);
  }
  for (const task of tasks) visit(task.id);
  return issues;
}

function calendarGroups(state) {
  const groups = new Map(state.eventSeries.map(series => [series.id, {id: 'series:' + series.id, series, events: []}]));
  const singles = [];
  for (const event of state.events) {
    const group = groups.get(event.seriesId);
    if (group) group.events.push(event);
    else singles.push({id: 'event:' + event.id, name: event.title, events: [event]});
  }
  return [...groups.values(), ...singles];
}

export function reconcile(base, local, remote, choice) {
  const unchanged = agreed(base, local, remote);
  if (unchanged !== disputed) return {result: unchanged, conflicts: []};
  const conflicts = new Set();
  function choose(label, b, l, r) {
    const value = agreed(b, l, r);
    if (value !== disputed) return value;
    conflicts.add(label);
    return choice === 'remote' ? r : l;
  }

  function ordered(label, before, left, right, rows) {
    const ids = items => items.map(row => row.id).filter(id => rows.has(id));
    const [b, l, r] = [before, left, right].map(ids);
    let order = agreed(b, l, r);
    if (order === disputed) {
      const inLocal = new Set(l), inRemote = new Set(r);
      const common = new Set(b.filter(id => inLocal.has(id) && inRemote.has(id)));
      const anchors = items => items.filter(id => common.has(id));
      order = choose(label + ' · order', anchors(b), anchors(l), anchors(r));
    }
    const placed = new Set(order);
    const additions = [...rows.keys()].filter(id => !placed.has(id)).sort();
    return [...order, ...additions].map(id => rows.get(id));
  }

  function records(label, before, left, right, mergeRow) {
    const same = agreed(before, left, right);
    if (same !== disputed) return same;
    const [b, l, r] = [before, left, right].map(indexRows), result = new Map();
    for (const id of new Set([...b.keys(), ...l.keys(), ...r.keys()])) {
      const old = b.get(id), mine = l.get(id), theirs = r.get(id);
      const row = mine ?? theirs ?? old;
      const name = label + ' · ' + (row.title || row.name || row.series?.title || id);
      let value = agreed(old, mine, theirs);
      if (value === disputed) {
        value = mergeRow && old && mine && theirs ? mergeRow(name, old, mine, theirs) : choose(name, old, mine, theirs);
      }
      if (value !== undefined) result.set(id, value);
    }
    return ordered(label, before, left, right, result);
  }

  function mergeHabit(label, b, l, r) {
    const versions = [b, l, r];
    if (versions.some(h => logFields.some(k => h[k] !== undefined && !isMap(h[k])))) return choose(label, b, l, r);
    const rules = versions.map(h => without(h, [...logFields, 'name', 'nameKey', 'icon']));
    const logs = h => logFields.map(k => h[k] ?? {});
    // A schedule/availability change can alter the meaning of the other device's log.
    if (!equal(rules[1], rules[2]) &&
        ((!equal(rules[0], rules[1]) && !equal(logs(b), logs(r))) ||
         (!equal(rules[0], rules[2]) && !equal(logs(b), logs(l))))) return choose(label, b, l, r);
    const metadata = versions.map(h => without(h, logFields));
    const result = {...choose(label, ...metadata)};
    for (const key of logFields) if (versions.some(h => Object.hasOwn(h, key))) result[key] = {};
    const dates = new Set(versions.flatMap(h => logFields.flatMap(k => Object.keys(h[k] ?? {}))));
    for (const date of dates) {
      // A check-in, its numeric value and its exception describe a single day.
      const entries = versions.map(h => Object.fromEntries(logFields
        .filter(k => Object.hasOwn(h[k] ?? {}, date)).map(k => [k, h[k][date]])));
      const day = choose(label + ' · ' + date, ...entries);
      for (const [key, value] of Object.entries(day)) result[key][date] = value;
    }
    return result;
  }

  function mergeProject(label, b, l, r) {
    if (![b, l, r].every(p => Array.isArray(p.tasks))) return choose(label, b, l, r);
    let tasks = records(label, b.tasks, l.tasks, r.tasks);
    let issues = dependencyIssues(tasks);
    if (issues.size) {
      // Choose only the dependent tasks. Independent siblings still merge.
      const preferred = indexRows(choose(label + ' · dependencies', undefined, l.tasks, r.tasks));
      const resolved = indexRows(tasks), handled = new Set();
      while (issues.size) {
        const fresh = [...issues].filter(id => !handled.has(id));
        if (!fresh.length) throw Error('SYNC_LINK_CONFLICT');
        for (const id of fresh) {
          if (preferred.has(id)) resolved.set(id, preferred.get(id));
          else resolved.delete(id);
          handled.add(id);
        }
        tasks = ordered(label, b.tasks, l.tasks, r.tasks, resolved);
        issues = dependencyIssues(tasks);
      }
    }
    const metadata = [b, l, r].map(row => without(row, ['tasks']));
    return {...choose(label, ...metadata), tasks};
  }

  function mergeBoard(label, b, l, r) {
    if (![b, l, r].every(board => Array.isArray(board.nodes) && Array.isArray(board.edges))) return choose(label, b, l, r);
    const metadata = [b, l, r].map(row => without(row, ['nodes', 'edges', 'updatedAt']));
    const nodes = records(label, b.nodes, l.nodes, r.nodes);
    const edges = choose(label + ' · edges', b.edges, l.edges, r.edges);
    const updatedAt = [b.updatedAt, l.updatedAt, r.updatedAt].filter(Boolean).sort().at(-1);
    return {...choose(label, ...metadata), nodes, edges, ...(updatedAt ? {updatedAt} : {})};
  }

  const result = {schema: 3};
  for (const key of collections) {
    if (key === 'events' || key === 'eventSeries') continue;
    const mergeRow = {habits: mergeHabit, projects: mergeProject, canvases: mergeBoard}[key];
    result[key] = records(key, base[key], local[key], remote[key], mergeRow);
  }
  // Recurrences and their materialized events must come from a consistent version.
  const calendars = [base, local, remote].map(s => ({events: s.events, eventSeries: s.eventSeries}));
  const calendar = agreed(...calendars);
  if (calendar !== disputed) {
    Object.assign(result, calendar);
  } else {
    const groups = records('Calendar', ...calendars.map(calendarGroups));
    const events = groups.flatMap(group => group.events);
    const series = groups.flatMap(group => group.series ? [group.series] : []);
    if (indexRows(events).size !== events.length) throw Error('LINKED_DELETE');
    result.events = ordered('Calendar', base.events, local.events, remote.events, indexRows(events));
    result.eventSeries = ordered('Calendar', base.eventSeries, local.eventSeries, remote.eventSeries, indexRows(series));
  }
  const prefs = [base, local, remote].map(s => s.exercisePreferences);
  result.exercisePreferences = Object.fromEntries([...new Set(prefs.flatMap(p => Object.keys(p)))].flatMap(key => {
    const value = choose('Sport · ' + key, ...prefs.map(p => Object.hasOwn(p, key) ? p[key] : undefined));
    return value === undefined ? [] : [[key, value]];
  }));
  return {result, conflicts: [...conflicts]};
}
