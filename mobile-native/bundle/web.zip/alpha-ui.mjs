import {defaultHabitSymbol,habitSymbolPicker,habitSymbolSvg} from './habit-symbols.mjs';
import * as model from './alpha-model.mjs';
import {boardScene,createCanvasViewer,edgeShape} from './canvas-viewer.mjs';
import {toggleTask} from './model.mjs';
import {list,taskEntry,projectTaskEditable,projectPercent} from './task-selectors.mjs';
import {dayKey,shiftDay,validDay} from './date-utils.mjs';
import {saveEvent} from './calendar-model.mjs';
import {actionButton} from './actions.mjs';
import {desktopHabitState} from './desktop-inspector.mjs';
import {testCommands,testHabitState} from './desktop-test-repository.mjs';
import {desktopTestText} from './desktop-test-i18n.mjs';
import {parseDesktopInput} from './desktop-adapter.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uuid=()=>crypto.randomUUID();
export function createAlphaUI({getState,commit,tr,label,language,icon,navigation,navigate,refresh,isStale,getError,getHabitDate=()=>dayKey(),setHabitDate=()=>{}}){
 const dialog=document.createElement('dialog');dialog.id='alpha-editor';dialog.setAttribute('aria-labelledby','alpha-heading');document.body.append(dialog);
 const $=id=>document.getElementById(id);
 const testing=()=>!!getState()?.desktopTest?.active;
 const testText=key=>desktopTestText(key,language());
 const allowed=(kind,id,projectId,command)=>testCommands(getState(),kind,id,projectId).includes(command);
 const restriction=()=>`<p class="muted" data-desktop-restriction>${esc(testText('readOnly'))}</p>`;
 const sourceDetails=value=>`<details><summary>${tr('details')}</summary><pre class="source-preview">${esc(JSON.stringify(value,null,2))}</pre></details>`;
 let selectedProject=null,selectedBoard=null,query='',showTrash=false,period='week',lastTrash=null,current=null,initial='',busy=false,lastFocus=null,afterClose=null;
 const canvasViewer=createCanvasViewer();
 let activeScene=null,drafts=new Map(),draftSession=null,draftWorkoutName='',recoveredWorkouts=[];
 const intro=key=>`<div class="intro"><h1>${tr(key)}</h1></div>`;
 const createActions=new Set(['new-habit','new-note','new-project','new-project-task','new-workout']);
 const actionIcons={'trash-note':'trash','delete-project-task':'trash','remove-exercise':'trash','edit-habit':'edit','edit-project':'edit','edit-workout':'edit','project-list':'back','board-list':'back'};
 const action=(key,code,id='',extra='')=>{if(testing()&&['new-habit','new-note','new-project','new-project-task','new-workout','archive-habit','check-history','trash-note','restore-note','delete-project-task','undo-project-task','plan-workout','start-workout','start-plan','log-set','save-workout-inputs','pause-workout','finish-workout','edit-project','edit-workout','edit-habit'].includes(code))return '';const glyph=code==='toggle-trash'?(key==='trash'?'trash':'back'):actionIcons[code];return actionButton(tr(key),{kind:createActions.has(code)?'create':glyph?'icon':'secondary',glyph,attrs:`data-alpha="${esc(code)}" data-id="${esc(id)}" ${extra}`});};
 const badge=key=>`<span class="state-label">${esc(tr(key))}</span>`;
 const shortDate=date=>new Intl.DateTimeFormat({en:'en-US',ru:'ru-RU',es:'es-ES'}[language()],{month:'short',day:'numeric'}).format(new Date(date+'T12:00:00'));
 const field=(id,key,control)=>`<label for="${esc(id)}">${tr(key)}</label>${control}`;
 const input=(id,value,attrs='')=>`<input id="${esc(id)}" value="${esc(value)}" ${attrs}>`;
 const area=(id,value,attrs='rows="4" maxlength="10000"')=>`<textarea id="${esc(id)}" ${attrs}>${esc(value)}</textarea>`;
 const options=(values,value,key=x=>x)=>values.map(v=>`<option value="${v}" ${value===v?'selected':''}>${tr(key(v))}</option>`).join('');
 const duration=ms=>{const sec=Math.floor(Math.max(0,ms)/1000);return String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0');};
 function error(key){$('alpha-error').textContent=key?tr(key):getError()||tr('saveError');$('alpha-error').hidden=false;$('alpha-refresh').hidden=!isStale();}
 const snapshot=()=>JSON.stringify([...dialog.querySelectorAll('input,textarea,select')].filter(x=>!x.closest('[data-numeric-step]')).map(x=>[x.id,x.type==='checkbox'||x.type==='radio'?x.checked:x.value]));
 function dirty(){return dialog.open&&snapshot()!==initial;}
 function close(){if(busy)return;if(dirty()){$('alpha-discard').hidden=false;$('alpha-continue').focus();}else dialog.close();}
 async function write(change,success){
  if(busy)return false;busy=true;dialog.dataset.busy='true';const submit=$('alpha-save');if(submit)submit.disabled=true;let problem;
  try{const ok=await commit(s=>{try{change(s);}catch(e){problem=e.message;throw e;}});if(ok){success?.();return true;}if(dialog.open)error(problem);return false;}
  finally{busy=false;delete dialog.dataset.busy;if(submit)submit.disabled=false;}
 }
 function beforeAction(fn){if(dirty()){error('saveBeforeAction');return;}return fn();}
 function buildEditor(title,body,{save=null,readOnly=false,actions='',kind,id,scope}={}){
  if(dialog.open)return;lastFocus=document.activeElement;current={kind,id,scope};
  dialog.innerHTML=`<form id="alpha-form"><div class="sheet-head"><span class="eyebrow">${tr('local')}</span><button type="button" id="alpha-close" class="icon-button" aria-label="${tr('close')}">×</button></div><h2 id="alpha-heading">${esc(title)}</h2>${readOnly?`<p class="muted">${tr('alphaReadOnly')}</p>`:''}<fieldset id="alpha-fields" ${readOnly?'disabled':''}>${body}</fieldset>${actions}<p id="alpha-error" class="error" role="alert" hidden></p><button type="button" id="alpha-refresh" class="action-button action-button--secondary" hidden>${tr('refreshData')}</button><section id="alpha-latest" hidden><h3>${tr('eventLatest')}</h3><p class="muted">${tr('eventReviewDraft')}</p><pre id="alpha-latest-values" class="source-preview"></pre></section><div id="alpha-discard" hidden><p>${tr('discardQuestion')}</p><button type="button" class="action-button action-button--secondary" id="alpha-continue">${tr('continueEdit')}</button><button type="button" class="action-button action-button--secondary" id="alpha-discard-confirm">${tr('discardEdit')}</button></div>${save&&!readOnly?`<button type="submit" id="alpha-save" class="primary">${testing()?testText('save'):tr('save')}</button>`:''}</form>`;
  navigation.suspend(true);dialog.showModal();initial=snapshot();
  $('alpha-close').onclick=close;$('alpha-continue').onclick=()=>{$('alpha-discard').hidden=true;(dialog.querySelector('input:not(:disabled),textarea:not(:disabled)')||$('alpha-close')).focus();};$('alpha-discard-confirm').onclick=()=>{if(!busy)dialog.close();};
  $('alpha-refresh').onclick=()=>{refresh();if(!isStale()){$('alpha-error').hidden=true;$('alpha-refresh').hidden=true;$('alpha-latest').hidden=false;$('alpha-latest-values').textContent=JSON.stringify(latestEntity(),null,2);if($('alpha-save'))$('alpha-save').textContent=tr('eventSaveDraft');}};
  $('alpha-form').addEventListener('invalid',e=>{e.preventDefault();e.target.closest('details')?.setAttribute('open','');error('invalid');e.target.focus();},true);
  $('alpha-form').onsubmit=async e=>{e.preventDefault();if(busy||readOnly||!save)return;let change;try{change=save();}catch(e){error(e.message);return;}const descriptor={...current};await write(s=>{if(descriptor.id&&['note','project','projectTask','habit','workout'].includes(descriptor.kind)&&!latestEntity(s,descriptor))throw Error('entityMissing');change(s);},()=>dialog.close());};
  (readOnly?$('alpha-close'):(dialog.querySelector('input:not(:disabled),textarea:not(:disabled)')||$('alpha-close'))).focus();
 }
 function latestEntity(s=getState(),descriptor=current){const {kind,id,scope}=descriptor||{};if(kind==='projectTask'){const tasks=list(s,'projects').find(p=>p.id===scope)?.tasks;return Array.isArray(tasks)?tasks.find(t=>t.id===id):null;}const key={note:'notes',project:'projects',habit:'habits',workout:'workouts'}[kind];return kind==='habit'?sharedHabit(s,id):key?list(s,key).find(x=>x.id===id):null;}
 dialog.addEventListener('cancel',e=>{e.preventDefault();close();});
 dialog.addEventListener('close',()=>{navigation.suspend(false);current=null;if(afterClose){const fn=afterClose;afterClose=null;fn();}else if(lastFocus?.isConnected)lastFocus.focus({preventScroll:true});else document.getElementById('content')?.focus({preventScroll:true});});
 window.addEventListener('beforeunload',e=>{if(dirty()||drafts.size||recoveredWorkouts.length){e.preventDefault();e.returnValue='';}});
 function habitEditor(id){
  if(testing()){const h=getState().habits.find(x=>x.id===id);if(h)return buildEditor(label(h),restriction()+testHabitDetails(h),{kind:'habit',id,readOnly:true});return;}
  const h=getState().habits.find(x=>x.id===id),rule=h?.schedules.filter(r=>r.from<=dayKey()).sort((a,b)=>b.from.localeCompare(a.from))[0],days=rule?.days.split(',').map(Number)||[0,1,2,3,4,5,6];
  const names=new Intl.DateTimeFormat({en:'en-US',ru:'ru-RU',es:'es-ES'}[language()],{weekday:'short'});
  buildEditor(tr(h?'editHabit':'createHabit'),field('habit-name','habitName',input('habit-name',h?label(h):'','required maxlength="500"'))+habitSymbolPicker(h?h.icon:defaultHabitSymbol,language())+field('habit-frequency','frequency',`<select id="habit-frequency">${options(['daily','days'],rule?.frequency||'daily',v=>v==='days'?'weekdays':'daily')}</select>`)+`<div class="weekdays">${[1,2,3,4,5,6,0].map(d=>`<label><input type="checkbox" name="habit-weekday" value="${d}" ${days.includes(d)?'checked':''}><span>${names.format(new Date(2026,10,8+d))}</span></label>`).join('')}</div><p class="muted">${tr('habitScope')}</p>`,{kind:'habit',id,save:()=>{const name=$('habit-name').value,fields={name:h?.nameKey&&label(h)===name?h.name:name,icon:dialog.querySelector('[name="habitIcon"]:checked')?.value,frequency:$('habit-frequency').value,days:[...dialog.querySelectorAll('[name="habit-weekday"]:checked')].map(x=>Number(x.value))},key=id||uuid();return s=>model.saveHabit(s,key,fields);},actions:h?action(h.archived?'restore':'archive','archive-habit',id)+action('history','habit-history',id):''});
 }
 function historyMarkup(id){
  const h=getState().habits.find(x=>x.id===id);if(!h)return '';
  if(testing())return restriction()+testHabitDetails(h);
  return `<p>${esc(label(h))}</p><p class="muted">${tr('habitHistory')}</p><div class="dated-history">${Array.from({length:14},(_,i)=>shiftDay(dayKey(),-i)).map(date=>`<button type="button" data-alpha="check-history" data-id="${esc(id)}" data-day="${date}" aria-pressed="${model.habitChecked(h,date)}" ${model.habitEligible(h,date)?'':'disabled'}><span>${esc(shortDate(date))}</span><span>${model.habitChecked(h,date)?icon('check'):'○'}</span></button>`).join('')}</div>`;
 }
 function noteEditor(id){
  const note=list(getState(),'notes').find(n=>n.id===id),readOnly=testing()? !note||!allowed('note',id,undefined,'noteBody'):!!note&&(!model.noteEditable(note)||!!note.deletedAt);
  buildEditor(tr(note?'editNote':'createNote'),field('note-title','title',input('note-title',note?.title||'',`required maxlength="500" ${testing()?'readonly':''}`))+field('note-body','noteBody',area('note-body',typeof note?.body==='string'?note.body:'','rows="9" maxlength="100000"'))+`<p class="muted">${testing()?esc(testText(readOnly?'noteProtected':'noteOnly')):tr('noteSource')}</p>${readOnly?`<pre class="source-preview">${esc(JSON.stringify(note,null,2))}</pre>`:''}`,{kind:'note',id,readOnly,save:()=>{const fields={title:$('note-title').value,body:$('note-body').value},key=id||uuid();return s=>{if(testing()){const n=s.notes.find(n=>n.id===key);if(!n)throw Error('entityMissing');n.body=fields.body;}else model.saveNote(s,key,fields);};},actions:note?action(note.deletedAt?'restore':'deleteNote',note.deletedAt?'restore-note':'trash-note',id):''});
 }
 function projectEditor(id){
  if(testing()){const p=list(getState(),'projects').find(p=>p.id===id);if(p)buildEditor(p.name,restriction()+sourceDetails(p),{kind:'project',id,readOnly:true});return;}
  const p=list(getState(),'projects').find(p=>p.id===id),readOnly=!!p&&(!['active','paused','completed'].includes(p.status)||!Array.isArray(p.tasks)||p.description!==undefined&&typeof p.description!=='string');
  buildEditor(tr(p?'editProject':'createProject'),field('project-name','projectName',input('project-name',p?.name||'','required maxlength="500"'))+field('project-description','description',area('project-description',p?.description||''))+field('project-status','projectStatus',`<select id="project-status">${options(['active','paused','completed'],p?.status||'active')}</select>`)+`<p class="muted">${tr('projectScope')}</p>`,{kind:'project',id,readOnly,save:()=>{const fields={name:$('project-name').value,description:$('project-description').value,status:$('project-status').value},key=id||uuid();return s=>model.saveProject(s,key,fields);}});
 }
 function projectTaskEditor(id,projectId){
  const s=getState(),p=list(s,'projects').find(p=>p.id===projectId),task=p?.tasks?.find(t=>t.id===id);if(!p)return;
  if(testing()){if(!task)return;const canComplete=allowed('task',id,projectId,'taskCompletion');return buildEditor(tr('projectTask'),`<h3>${esc(task.title)}</h3><p class="muted">${esc(testText(canComplete?'taskOnly':'taskProtected'))}</p>${sourceDetails(task)}`,{kind:'projectTask',id,scope:projectId,readOnly:true,actions:canComplete?action(task.status==='done'?'undo':'complete','test-task-completion',id,`data-project="${esc(projectId)}"`):''});}
  const readOnly=!!task&&!projectTaskEditable(s,{task,project:p});
  buildEditor(tr('projectTask'),field('project-task-title','title',input('project-task-title',task?.title||'','required maxlength="500"'))+field('project-task-status','taskStatus',`<select id="project-task-status">${options(['planned','progress','done'],task?.status||'planned',v=>v==='progress'?'taskInProgress':v)}</select>`)+field('project-task-deadline','deadline',input('project-task-deadline',task?.deadline||'','type="date" min="2000-01-01" max="2099-12-31"'))+field('project-task-importance','eventPriority',`<select id="project-task-importance">${options(['none','low','medium','high'],task?.importance||'none',v=>'importance'+v)}</select>`)+field('project-task-description','description',area('project-task-description',task?.description||''))+`${readOnly?`<pre class="source-preview">${esc(JSON.stringify(task,null,2))}</pre>`:''}`,{kind:'projectTask',id,scope:projectId,readOnly,save:()=>{const fields={title:$('project-task-title').value,status:$('project-task-status').value,deadline:$('project-task-deadline').value,importance:$('project-task-importance').value,description:$('project-task-description').value},key=id||uuid();return s=>model.saveProjectTask(s,projectId,key,fields);},actions:task&&!readOnly?`${task.deadline?action('makeMain','main-project-task',id,`data-project="${esc(projectId)}"`):''}${action('deleteTask','delete-project-task',id,`data-project="${esc(projectId)}"`)}`:''});
 }
 function exerciseRow(e){return `<section class="exercise-editor" data-exercise="${esc(e.id)}">${field('ex-name-'+e.id,'exercise',input('ex-name-'+e.id,e.name,'data-ex-name required maxlength="500"'))}<div class="form-grid"><div>${field('ex-sets-'+e.id,'sets',input('ex-sets-'+e.id,e.sets,'data-ex-sets type="number" min="1" max="30" step="1" required'))}</div><div>${field('ex-target-'+e.id,'target',input('ex-target-'+e.id,e.target,'data-ex-target maxlength="100"'))}</div><div>${field('ex-rest-'+e.id,'rest',input('ex-rest-'+e.id,e.rest,'data-ex-rest type="number" min="0" max="1200" step="1" required'))}</div><div>${field('ex-unit-'+e.id,'unit',`<select id="ex-unit-${esc(e.id)}" data-ex-unit>${options(['reps','seconds','kg'],e.unit||'reps')}</select>`)}</div></div>${action('removeExercise','remove-exercise',e.id)}</section>`;}
 function workoutEditor(id){
  if(testing()){const w=list(getState(),'workouts').find(w=>w.id===id);if(w)buildEditor(w.name,restriction()+sourceDetails(w),{kind:'workout',id,readOnly:true});return;}
  const w=list(getState(),'workouts').find(w=>w.id===id),readOnly=!!w&&!model.templateEditable(w);
  const exercises=w?.exercises||[{id:uuid(),name:'',sets:3,target:'8',rest:60,unit:'reps'}];
  buildEditor(tr(w?'editWorkout':'createWorkout'),field('workout-name','workoutName',input('workout-name',w?.name||'','required maxlength="500"'))+field('workout-detail','description',area('workout-detail',w?.detail||''))+field('workout-duration','eventDuration',input('workout-duration',w?.duration||30,'type="number" min="15" max="1440" step="15" required'))+`<div id="exercise-rows">${Array.isArray(exercises)?exercises.map(exerciseRow).join(''):''}</div>${readOnly?'':action('addExercise','add-exercise')}<p class="muted">${tr('snapshotNote')}</p>${readOnly?`<pre class="source-preview">${esc(JSON.stringify(w,null,2))}</pre>`:''}`,{kind:'workout',id,readOnly,save:()=>{const fields={name:$('workout-name').value,detail:$('workout-detail').value,duration:Number($('workout-duration').value),exercises:[...dialog.querySelectorAll('[data-exercise]')].map(row=>({id:row.dataset.exercise,name:row.querySelector('[data-ex-name]').value,sets:Number(row.querySelector('[data-ex-sets]').value),target:row.querySelector('[data-ex-target]').value,rest:Number(row.querySelector('[data-ex-rest]').value),unit:row.querySelector('[data-ex-unit]').value}))},key=id||uuid();return s=>model.saveTemplate(s,key,fields);},actions:w&&!readOnly?action('planWorkout','plan-workout',id)+action('startWorkout','start-workout',id):''});
 }
 function planEditor(id){buildEditor(tr('planWorkout'),field('plan-date','date',input('plan-date',dayKey(),'type="date" required min="2000-01-01" max="2099-12-31"'))+field('plan-time','eventStart',input('plan-time','18:00','type="time" step="900" required'))+`<label class="event-check"><input type="checkbox" id="plan-overlap">${tr('eventAllowOverlap')}</label><p class="muted">${tr('snapshotNote')}</p>`,{kind:'plan',id,save:()=>{const fields={date:$('plan-date').value,time:$('plan-time').value},allowOverlap=$('plan-overlap').checked,key=uuid();return s=>model.planWorkout(s,id,key,fields,(s,id,f)=>saveEvent(s,id,f,{allowOverlap}));}});}
 function open(kind,id=null,scope=null){
  if(busy||dialog.open||isStale())return;
  if(testing()&&(!id||['plan','finish'].includes(kind)))return;
  if(kind==='habit')return habitEditor(id);if(kind==='note')return noteEditor(id);if(kind==='project')return projectEditor(id);if(kind==='projectTask')return projectTaskEditor(id,scope);if(kind==='workout')return workoutEditor(id);if(kind==='plan')return planEditor(id);
  if(kind==='habit-history')return buildEditor(tr('history'),`<div id="habit-history-content">${historyMarkup(id)}</div>`,{kind,id});
  if(kind==='result'){
   const r=list(getState(),'workoutRecords').find(r=>r.id===id);if(!r)return;
   return buildEditor(tr('workoutResult'),`<h3>${esc(r.snapshot?.name||r.title||r.id)}</h3><p>${esc(r.endedAt?new Date(r.endedAt).toLocaleString(language()):'')}</p><p>${tr('elapsed')}: ${duration(r.durationMs||0)}</p>${Array.isArray(r.sets)?r.sets.map(set=>`<div class="result-row"><span>${esc(set.name)} · ${Number(set.index)}</span><span>${set.done?'✓':'—'} ${esc(set.result)} ${esc(tr(set.unit||'reps'))}${set.mobileLoadKg!==undefined?' · '+esc(set.mobileLoadKg)+' kg':''}</span></div>`).join(''):''}<details><summary>${tr('details')}</summary><pre class="source-preview">${esc(JSON.stringify(r,null,2))}</pre></details>`,{kind,id});
  }
  if(kind==='finish')return buildEditor(tr('finish'),`<p>${tr('finishQuestion')}</p>`,{kind,id,save:()=>s=>model.finishWorkout(s)});
  if(kind==='node'){
   const b=list(getState(),'canvases').find(b=>b.id===scope),source=b?.nodes?.find(n=>n.id===id);if(!source)return;const node=model.canvasNodeProjection(getState(),source);
   return buildEditor(tr('nodeContent'),canvasImage(node)||`<h3>${esc(node.title)}</h3><pre class="source-preview">${esc(node.body||'')}</pre><details><summary>${tr('details')}</summary><pre class="source-preview">${esc(JSON.stringify(node,null,2))}</pre></details>`,{kind,id,scope});
  }
 }
 function collectionGuard(key){return Array.isArray(getState()[key])?'':`<p class="error">${tr('localCollectionLimit')}</p>`;}
 function testHabitDetails(h){
  const dates=[...new Set([...Object.keys(h.values||{}),...Object.keys(h.checkIns||{}),...Object.keys(h.exceptions||{})])].sort();
  return `<h3>${esc(testText('schedule'))}</h3>${(h.schedules||[]).map(r=>`<p class="muted">${esc(r.from)} · ${esc(r.frequency)} · ${esc(r.kind)} · ${esc(r.goal)}${r.weekTarget!==undefined?' × '+esc(r.weekTarget):''} · ${esc(testText('source'))}: ${esc(r.source)}${r.frequency==='days'?' · '+esc(r.days):''}</p>`).join('')}<h3>${esc(testText('history'))}</h3>${dates.length?dates.map(d=>`<div class="result-row"><span>${esc(d)}</span><span>${h.values?.[d]!==undefined?esc(h.values[d]):h.checkIns?.[d]!==undefined?String(h.checkIns[d]):'—'}${h.exceptions?.[d]?' · '+esc(h.exceptions[d]):''}</span></div>`).join(''):`<p class="muted">${esc(testText('unavailableHistory'))}</p>`}${sourceDetails(h)}`;
 }
 function habitReason(status){return testText(status.reason||'habitUnsupported');}
 function habitValueLabel(h,date,status){if(status.reason==='habitSportSource')return testText('habitDerived');const present=Object.hasOwn(h.values||{},date)||Object.hasOwn(h.checkIns||{},date),raw=h.values?.[date]??Number(h.checkIns?.[date]||false),unit=status.supported||status.reason==='habitWeekly'?status.unit:'';return present?String(raw)+(unit?' '+testText(unit):''):testText('noRecord');}
 function habitSection(date,{compact=false,selectDate=true}={}){
  const state=getState(),cards=state.habits.map(h=>{
   const status=testHabitState(state,h,date),editable=status.supported&&status.eligible,binary=status.kind==='completion',name=esc(label(h)),value=esc(habitValueLabel(h,date,status)),reason=editable?'':habitReason(status),press=!!status.done;
   const attrs=`id="habit-${esc(h.id)}" data-habit="${esc(h.id)}" data-habit-day="${esc(date)}" aria-pressed="${press}" aria-label="${esc(tr(press?'unmark':'mark'))}: ${name}" ${editable&&binary?'':'disabled'}`;
   if(compact){
    if(binary&&status.supported)return `<button class="habit" ${attrs}><span class="habit-icon">${habitSymbolSvg(h.icon)}</span><span>${name}</span><small>${value}</small>${reason?`<small>${esc(reason)}</small>`:''}</button>`;
    return `<article class="habit"><h3 class="habit-symbol-title">${habitSymbolSvg(h.icon)}<span>${name}</span></h3><p>${value}</p>${editable?`<button type="button" class="action-button action-button--secondary" data-test-habit-value="${esc(h.id)}" data-day="${esc(date)}">${esc(testText('setValue'))}</button>`:`<small>${esc(reason)}</small>`}</article>`;
   }
   const controls=editable?(binary?`<div class="row-actions"><button class="check" ${attrs}><span class="tick">${icon('check')}</span></button><span>${esc(tr(press?'unmark':'mark'))}</span></div>`:`<button type="button" class="action-button action-button--secondary" data-test-habit-value="${esc(h.id)}" data-day="${esc(date)}">${esc(testText('setValue'))}</button>`):`<p class="muted" data-habit-restriction>${esc(reason)}</p>`;
   return `<article class="alpha-card habit-record" data-habit-record="${esc(h.id)}"><h2 class="habit-symbol-title">${habitSymbolSvg(h.icon)}<span>${name}</span></h2><p data-habit-value="${esc(h.id)}">${value}${(status.supported||status.reason==='habitWeekly')&&Number.isFinite(status.goal)&&status.goal>0?' / '+esc(status.goal)+(status.unit?' '+esc(testText(status.unit)):''):''}</p>${controls}<details><summary>${esc(testText('history'))}</summary>${testHabitDetails(h)}</details></article>`;
  }).join('');
  return `<section class="habits"><div class="section-head"><h2>${tr('habits')}</h2></div>${selectDate?`<label for="desktop-habit-date">${esc(testText('habitDateLabel'))}</label><input id="desktop-habit-date" type="date" value="${esc(date)}" min="2000-01-01" max="${dayKey()}">`:`<p class="muted">${esc(shortDate(date))}</p>`}<p class="muted">${esc(testText('habitScope'))}</p><div class="${compact?'habit-grid':'habit-records'}">${cards}</div></section>`;
 }
 function sharedHabit(state,id){return state.workspaceReadOnly?.['habits:'+id] || state.habits.find(h=>h.id===id);}
 function valueStatus(state,habit,date){return testing()?testHabitState(state,habit,date):desktopHabitState(habit,date);}
 function habitValueEditor(id,date){
  const h=sharedHabit(getState(),id);if(!h)return;const status=valueStatus(getState(),h,date);
  if(!status.supported||!status.eligible||status.kind==='completion')return buildEditor(label(h),`<p>${esc(habitReason(status))}</p>`+testHabitDetails(h),{kind:'habit',id,readOnly:true});
  const present=Object.hasOwn(h.values||{},date)||Object.hasOwn(h.checkIns||{},date);
  buildEditor(label(h),`<p>${esc(shortDate(date))} · ${esc(testText(status.unit))}</p><label for="test-habit-value">${esc(testText('actualValue'))}</label><input id="test-habit-value" type="number" min="0" step="any" required inputmode="decimal" value="${present?esc(status.value):''}"><p class="muted">${esc(testText('habitExactInput'))}</p>`,{kind:'habit',id,scope:date,save:()=>{let value;try{value=parseDesktopInput($('test-habit-value').value.trim().replace(',','.'));}catch{throw Error('invalid');}if(typeof value!=='number'||!Number.isFinite(value)||value<0)throw Error('invalid');return s=>{const habit=sharedHabit(s,id),current=valueStatus(s,habit,date);if(!current.supported||!current.eligible||current.kind==='completion')throw Error('alphaReadOnly');(habit.values??={})[date]=value;};},actions:action('unmark','test-habit-clear',id,`data-day="${esc(date)}"`)});
 }
 function testSportView(){
  const s=getState();return intro('sport')+`<p class="muted" data-desktop-restriction>${esc(testText('sportProtected'))}</p><h2>${tr('library')}</h2>`+list(s,'workouts').map(w=>`<article class="alpha-card"><h2>${esc(w.name)}</h2><p class="muted">${esc(w.detail||'')}</p>${(w.exercises||[]).map(e=>`<p>${esc(e.name)} · ${esc(e.sets)} × ${esc(e.target)} ${esc(e.unit)}</p>`).join('')}${sourceDetails(w)}</article>`).join('')+`<h2>${tr('plannedWorkouts')}</h2>`+s.events.filter(e=>e.type==='workout'&&e.plannedSnapshot&&!e.done).map(e=>`<article class="alpha-card"><h3>${esc(e.title)}</h3><p class="muted">${esc(e.date)}</p>${sourceDetails(e.plannedSnapshot)}</article>`).join('')+`<h2>${tr('history')}</h2>`+list(s,'workoutRecords').map(r=>`<article class="alpha-card"><h3>${esc(r.snapshot?.name||r.title||r.id)}</h3><p class="muted">${esc(r.completedDate||r.endedAt||'')}</p>${(r.sets||[]).map(set=>`<div class="result-row"><span>${esc(set.name)} · ${esc(set.index)}</span><span>${set.actualValue!==undefined?esc(set.actualValue):set.result!==undefined?esc(set.result):'—'} ${esc(set.unit)}</span></div>`).join('')}${sourceDetails(r)}</article>`).join('');
 }
 function testProgressView(){
  const s=getState(),tasks=[...s.homeTasks,...list(s,'projects').flatMap(p=>p.tasks||[])].filter(t=>(t.done||t.status==='done')&&t.completedAt),focus=list(s,'focusRecords'),records=list(s,'workoutRecords').filter(r=>r.endedAt||r.completedDate);
  return intro('progress')+`<p class="muted">${esc(testText('confirmed'))}. ${esc(testText('readOnly'))}</p><h2>${tr('completedTasks')}</h2>${tasks.length?tasks.map(t=>`<div class="list-item"><span>${esc(t.title)}</span><small>${esc(t.completedAt)}</small></div>`).join(''):`<p class="muted">${esc(testText('unavailableHistory'))}</p>`}<h2>${esc(testText('focus'))}</h2>${focus.length?focus.map(r=>`<div class="list-item"><span>${esc(r.date)}</span><span>${esc(r.minutes)} ${esc(testText('minutes'))}</span></div>`).join(''):`<p class="muted">${esc(testText('unavailableHistory'))}</p>`}<h2>${tr('completedWorkouts')}</h2>${records.length?records.map(r=>`<div class="list-item"><span>${esc(r.snapshot?.name||r.id)}</span><small>${esc(r.completedDate||r.endedAt)}</small></div>`).join(''):`<p class="muted">${esc(testText('unavailableHistory'))}</p>`}<h2>${tr('habits')}</h2>${s.habits.map(h=>`<article class="alpha-card"><h3 class="habit-symbol-title">${habitSymbolSvg(h.icon)}<span>${esc(label(h))}</span></h3><p>${Object.entries(h.values||{}).map(([d,v])=>esc(d)+': '+esc(v)).join(' · ')||esc(testText('unavailableHistory'))}</p></article>`).join('')}<h2>${tr('projects')}</h2>${list(s,'projects').map(p=>`<div class="list-item"><span>${esc(p.name)}</span><span>${projectPercent(p)}%</span></div>`).join('')}`;
 }
 function habitsView(){
  if(testing())return intro('navHabits')+habitSection(getHabitDate());
  const s=getState();return intro('navHabits')+action('createHabit','new-habit')+`<p class="muted">${tr('habitScope')}</p>`+s.habits.map(h=>`<article class="alpha-card habit-record"><div class="section-head"><h2 class="habit-symbol-title">${habitSymbolSvg(h.icon)}<span>${esc(label(h))}</span></h2>${h.archived?badge('archived'):''}</div><p class="muted">${tr('streak')}: ${model.habitStreak(h,dayKey())}</p><div class="row-actions">${model.habitEligible(h,dayKey())?`<button class="check" id="habit-${esc(h.id)}" data-habit="${esc(h.id)}" aria-pressed="${model.habitChecked(h,dayKey())}" aria-label="${tr(model.habitChecked(h,dayKey())?'unmark':'mark')}: ${esc(label(h))}"><span class="tick">${icon('check')}</span></button>`:''}${action('editHabit','edit-habit',h.id)}${action('history','habit-history',h.id)}</div></article>`).join('');
 }
 function notesView(){return intro(showTrash?'trash':'notes')+collectionGuard('notes')+`<div class="toolbar">${action('createNote','new-note')}${action(showTrash?'notes':'trash','toggle-trash')}</div>${field('note-search','search',input('note-search',query,'type="search" autocomplete="off"'))}<div id="note-results">${noteRows()}</div>`;}
 function noteRows(){const rows=model.searchNotes(getState(),query,showTrash),undo=lastTrash&&!showTrash?`<p role="status">${tr('deleted')} ${action('undoDelete','restore-note',lastTrash)}</p>`:'';return undo+(rows.length?rows.map(n=>`<article class="list-item"><button type="button" class="item-title" data-alpha="edit-note" data-id="${esc(n.id)}"><span>${esc(n.title)}</span><small>${esc((typeof n.body==='string'?n.body:'').slice(0,90))}</small></button>${n.deletedAt?action('restore','restore-note',n.id):''}</article>`).join(''):`<p class="empty">${tr(query?'noMatchingNotes':'noNotes')}</p>`);}
 function projectsView(){
  const s=getState(),p=list(s,'projects').find(p=>p.id===selectedProject);
  if(p)return intro('projects')+action('back','project-list')+`<path-share-entry kind="project" data-source="${esc(p.id)}"></path-share-entry>`+`<article class="alpha-card"><div class="section-head"><h2>${esc(p.name)}</h2>${badge(p.status)}</div><p class="note-text">${esc(p.description)}</p><p>${projectPercent(p)}%</p>${action('editProject','edit-project',p.id)}</article><div class="toolbar">${!p.archived&&['active','paused','completed'].includes(p.status)&&Array.isArray(p.tasks)?action('newProjectTask','new-project-task',p.id):''}</div>${Array.isArray(p.tasks)?p.tasks.map(task=>`<div class="task-row ${task.status==='done'?'completed':''}"><button class="check" id="task-${esc(task.id)}" data-task="${esc(task.id)}" aria-pressed="${task.status==='done'}" aria-label="${tr(task.status==='done'?'undo':'complete')}: ${esc(task.title)}" ${(testing()?allowed('task',task.id,p.id,'taskCompletion'):projectTaskEditable(s,{task,project:p}))?'':'disabled'}><span class="tick">${icon('check')}</span></button><button type="button" class="item-title" data-alpha="edit-project-task" data-id="${esc(task.id)}" data-project="${esc(p.id)}"><span>${esc(task.title)}</span><small>${esc(tr(task.status==='progress'?'taskInProgress':task.status))}${task.deadline?' · '+esc(task.deadline):''}</small></button></div>`).join(''):tr('alphaReadOnly')}<p class="muted">${tr('projectScope')}</p>${s.mobileProjectUndo?action('undoDelete','undo-project-task'):''}`;
  return intro('projects')+collectionGuard('projects')+action('createProject','new-project')+'<path-shared-library kind="project"></path-shared-library>'+list(s,'projects').map(p=>`<button type="button" class="alpha-card project-card" data-alpha="open-project" data-id="${esc(p.id)}">${icon('projects')}<h2>${esc(p.name)}</h2><small>${esc(tr(p.status))} · ${projectPercent(p)}%</small></button>`).join('')+(list(s,'projects').length?'':`<p class="empty">${tr('noProjects')}</p>`)+(s.mobileProjectUndo?action('undoDelete','undo-project-task'):'');
 }
 function prepareDraftSession(session){
  const next=session?.mobileSessionVersion===1?session.id:null,ids=new Set(session?.sets?.map(s=>s.id)||[]),orphaned=[...drafts].filter(([id])=>next!==draftSession||!ids.has(id));
  if(orphaned.length){recoveredWorkouts.push({id:uuid(),sessionId:draftSession,name:draftWorkoutName,inputs:orphaned.map(([id,values])=>({id,...values}))});for(const [id]of orphaned)drafts.delete(id);}
  draftSession=next;draftWorkoutName=session?.snapshot?.name||'';
 }
 function recoveredWorkoutView(){return recoveredWorkouts.map(r=>`<aside class="alpha-card recovered-workout" data-recovered-workout="${esc(r.id)}" role="region" aria-label="${tr('workoutRecovered')}"><h2>${tr('workoutRecovered')}</h2><p role="status">${tr('workoutRecoveredNote')}</p><p class="recovered-values">${r.inputs.map(v=>esc(v.name||v.id)+(v.index?' · '+esc(v.index):'')+': '+esc(v.result||'—')+' '+esc(tr(v.unit||''))+(v.load!==''&&v.load!==undefined?' · '+esc(v.load)+' kg':'')).join('<br>')}</p><label for="recovered-${esc(r.id)}">${esc(r.name)}</label><textarea id="recovered-${esc(r.id)}" readonly rows="6">${esc(JSON.stringify({sessionId:r.sessionId,workout:r.name,inputs:r.inputs},null,2))}</textarea><details><summary>${tr('discardRecovered')}</summary><p>${tr('workoutRecoveredDiscard')}</p>${action('discardRecoveredConfirm','discard-workout-recovery',r.id)}</details></aside>`).join('');}
 function savedWorkoutHint(set,draft){return draft?`<p class="muted" data-saved-workout-value="${esc(set.id)}">${tr('savedWorkoutValue')}: ${esc(set.result||'—')} ${esc(tr(set.unit))}${set.mobileLoadKg!==undefined?' · '+esc(set.mobileLoadKg)+' kg':''}</p>`:'';}
 function activeView(session){
  if(session.mobileSessionVersion!==1)return `<p class="error">${tr('alphaReadOnly')}</p><pre class="source-preview">${esc(JSON.stringify(session,null,2))}</pre>`;
  return `<section class="active-workout"><span class="eyebrow">${tr('activeWorkout')}</span><h2>${esc(session.snapshot.name)}</h2><div class="workout-clock"><span>${tr('elapsed')} <output data-workout-elapsed>${duration(model.workoutElapsed(session))}</output></span><span>${tr('restLeft')} <output data-workout-rest>${duration(model.restRemaining(session))}</output></span></div><div class="toolbar">${action(session.pausedAt?'resume':'pause','pause-workout')}${action('finish','finish-workout')}</div>${session.sets.map(set=>{const draft=drafts.get(set.id);return `<section class="workout-set ${set.done?'set-done':''}" data-workout-set="${esc(set.id)}"><h3>${esc(set.name)} · ${Number(set.index)} / ${session.snapshot.exercises.find(e=>e.id===set.exerciseId)?.sets||''}</h3><p class="muted">${tr('target')}: ${esc(set.target)} ${tr(set.unit)}</p>${savedWorkoutHint(set,draft)}<div class="form-grid"><div>${field('result-'+set.id,'result',input('result-'+set.id,draft?.result??set.result,`data-set-result data-numeric-unit="${set.unit}" inputmode="decimal" type="number" min="0" max="100000" step="${set.unit==='reps'?'1':'any'}" ${session.pausedAt?'disabled':''}`))}</div><div>${field('load-'+set.id,'load',input('load-'+set.id,draft?.load??set.mobileLoadKg??'',`data-set-load inputmode="decimal" type="number" min="0" max="10000" step="any" ${session.pausedAt?'disabled':''}`))}</div></div><button type="button" class="set-log" data-alpha="log-set" data-id="${esc(set.id)}" aria-pressed="${set.done}" ${session.pausedAt?'disabled':''}>${set.done?icon('check'):''}${tr(set.done?'unmark':'logSet')}</button></section>`;}).join('')}<p class="muted">${tr('loadExtension')}</p>${action('saveInputs','save-workout-inputs')}<p class="error" id="workout-error" role="alert" hidden></p></section>`;
 }
 function sportView(){
  if(testing())return testSportView();
  const s=getState();prepareDraftSession(s.activeWorkout);
  return intro('sport')+collectionGuard('workouts')+recoveredWorkoutView()+(s.activeWorkout?activeView(s.activeWorkout):'')+`<div class="section-head"><h2>${tr('library')}</h2>${action('createWorkout','new-workout')}</div>`+list(s,'workouts').map(w=>`<article class="alpha-card"><div class="section-head">${icon('sport')}<h2>${esc(w.name)}</h2></div><p class="muted">${Array.isArray(w.exercises)?w.exercises.map(e=>esc(e.name)+' × '+esc(e.sets)).join(' · '):tr('readOnly')}</p><div class="row-actions">${action('editWorkout','edit-workout',w.id)}${model.templateEditable(w)?action('planWorkout','plan-workout',w.id)+(!s.activeWorkout?action('startWorkout','start-workout',w.id):''):''}</div></article>`).join('')+(list(s,'workouts').length?'':`<p class="empty">${tr('noWorkouts')}</p>`)+`<h2>${tr('plannedWorkouts')}</h2>`+s.events.filter(e=>e.type==='workout'&&e.plannedSnapshot&&!e.done).map(e=>`<article class="list-item"><div><strong>${esc(e.title)}</strong><p class="muted">${esc(e.date)} · ${String(Math.floor(e.hour)).padStart(2,'0')}:${String(Math.round(e.hour%1*60)).padStart(2,'0')}</p></div>${model.templateEditable(e.plannedSnapshot)&&!s.activeWorkout?action('startWorkout','start-plan',e.id):badge('readOnly')}</article>`).join('')+`<h2>${tr('history')}</h2>`+list(s,'workoutRecords').filter(r=>r.endedAt).slice().reverse().map(r=>`<button type="button" class="list-item history-result" data-alpha="result" data-id="${esc(r.id)}"><span>${esc(r.snapshot?.name||r.title||r.id)}</span><small>${esc(new Date(r.endedAt).toLocaleDateString(language()))}</small></button>`).join('')+(list(s,'workoutRecords').length?'':`<p class="empty">${tr('emptyHistory')}</p>`)+`<p class="muted">${tr('programLimit')}</p>`;
 }
 function canvasImage(node){
  if(typeof node.image!=='string'||!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/.test(node.image))return '';
  return `<img class="canvas-photo" decoding="async" draggable="false" src="${esc(node.image)}" alt="${esc(node.title||tr('nodeContent'))}">`;
 }
 function canvasLink(edge,scene){
  const shape=edgeShape(edge,scene);
  const width=[1,1.5,2.5].includes(edge.lineWidth)?edge.lineWidth:1.5;
  return `<g><path d="${shape.path}" stroke-width="${width}"${edge.lineStyle==='dashed'?' stroke-dasharray="7 5"':''}${edge.directed===false?'':' marker-end="url(#canvas-arrow)"'}/>${edge.label?`<text x="${shape.x}" y="${shape.y}" text-anchor="middle">${esc(edge.label)}</text>`:''}</g>`;
 }
 function canvasCard(n,boardId){
  const title=n.title||n.kind||tr('nodeContent'),body=typeof n.body==='string'?n.body:'';
  let content=canvasImage(n);
  if(!content){
   const showTitle=n.kind!=='note'||!body;
   const detail=n.kind==='checklist'?body.split('\n').map(line=>esc(line.replace(/^\[([ x])\]\s*/i,(_,mark)=>mark.toLowerCase()==='x'?'☑ ':'☐ '))).join('\n'):esc(body);
   content=(showTitle?`<strong>${esc(title)}</strong>`:'')+(detail?`<span class="canvas-text">${detail}</span>`:'');
  }
  return `<button type="button" class="canvas-node" data-kind="${esc(n.kind||'note')}" data-alpha="open-node" data-id="${esc(n.id)}" data-board="${esc(boardId)}" aria-label="${esc(title)}">${content}</button>`;
 }
 function boardHeader(board){
  return `<header class="canvas-heading">${action('back','board-list')}<h1 id="canvas-title">${esc(board.name||board.title||board.id)}</h1></header>`;
 }
 function canvasView(){
  const board=list(getState(),'canvases').find(b=>b.id===selectedBoard);
  if(!board)return intro('canvas')+collectionGuard('canvases')+'<path-shared-library kind="canvas"></path-shared-library>'+list(getState(),'canvases').map(b=>`<button type="button" class="alpha-card board-card" data-alpha="open-board" data-id="${esc(b.id)}">${icon('canvas')}<span>${esc(b.name||b.title||b.id)}</span></button>`).join('')+(list(getState(),'canvases').length?'':`<p class="empty">${tr('noBoards')}</p>`);
  if(!model.boardViewable(board))return boardHeader(board)+ `<p class="muted">${esc(testText('canvasLimit'))}</p>${(board.nodes||[]).map(n=>{
   const photo=canvasImage(n);
   if(photo)return `<article class="alpha-card">${photo}</article>`;
   const node=model.canvasNodeProjection(getState(),n);
   return `<article class="alpha-card"><h3>${esc(node.title||n.kind)}</h3><p>${esc(node.body||'')}</p><p>${esc(n.kind)}${n.collapsed?' · '+esc(tr('readOnly')):''}</p><p class="muted">${esc(testText('coordinates'))}: ${esc(n.x)}, ${esc(n.y)} · ${esc(n.width)} × ${esc(n.height)}</p>${sourceDetails(n)}</article>`;}).join('')}<h2>${esc(testText('relations'))}</h2>${(board.edges||[]).map(e=>`<p class="muted">${esc(e.from)} → ${esc(e.to)}${e.label?' · '+esc(e.label):''}</p>`).join('')}`;
  activeScene=boardScene(board,n=>model.canvasNodeProjection(getState(),n));
  return `<section class="canvas-reader">${boardHeader(board)}<path-share-entry kind="canvas" data-source="${esc(board.id)}"></path-share-entry>
    <span class="sr-only" id="canvas-gestures">${esc(tr('canvasReadOnly'))}</span>
    <div class="canvas-viewport" tabindex="0" role="region" aria-labelledby="canvas-title" aria-describedby="canvas-gestures">
      <div class="canvas-grid" aria-hidden="true"></div><div class="canvas-world">
      <svg class="canvas-edges" aria-hidden="true"><defs><marker id="canvas-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0 10 5 0 10Z" fill="#a4a6a9"/></marker></defs>${activeScene.edges.map(edge=>canvasLink(edge,activeScene)).join('')}</svg>
      ${activeScene.nodes.map(n=>canvasCard(n,board.id)).join('')}</div>
    </div></section>`;
 }
 function progressView(){if(testing())return testProgressView();const p=model.progressData(getState(),period);for(let date=p.from;date<=p.to;date=shiftDay(date,1)){
   for(const [key,row] of Object.entries(getState().workspaceReadOnly||{})){
    if(!key.startsWith('habits:'))continue;
    const status=desktopHabitState(row,date);
    if(status.supported&&status.eligible){p.habitEligible++;if(status.done)p.habitChecked++;}
   }
  }
  const focus=list(getState(),'focusRecords').filter(r=>r.date>=p.from&&r.date<=p.to).reduce((sum,r)=>sum+r.minutes,0);return intro('progress')+field('progress-period','period',`<select id="progress-period">${options(['day','week','month'],period)}</select>`)+`<p class="muted">${p.from} — ${p.to}</p><dl class="progress-stats">${focus?`<div><dt>${esc(testText('focus'))}</dt><dd>${focus} ${esc(testText('minutes'))}</dd></div>`:''}<div><dt>${tr('completedTasks')}</dt><dd>${p.tasks}</dd></div><div><dt>${tr('habitRate')}</dt><dd>${p.habitChecked} / ${p.habitEligible}</dd></div><div><dt>${tr('completedWorkouts')}</dt><dd>${p.workouts}</dd></div></dl><h2>${tr('projects')}</h2>${p.projects.map(project=>`<div class="list-item"><span>${esc(project.name)}</span><span>${project.percent}%</span></div>`).join('')}<p class="muted">${tr('progressFormula')}</p>`;}
 function view(route){
  const personal=getState().personalSync;
  if(personal&&globalThis.pathPersonal&&(route==='profile'||route==='sync')){
   const detail=route==='profile'?globalThis.pathPersonal.email:tr('revision')+' · '+personal.base.revision;
   return intro(route)+`<article class="alpha-card"><h2>${tr('personalAccount')}</h2><p>${esc(detail||'')}</p>${action('exchangeStatus','exchange-status')}</article>`;
  }
  if(route==='habits')return habitsView();if(route==='notes')return notesView();if(route==='projects')return projectsView();if(route==='sport')return sportView();if(route==='canvas')return canvasView();if(route==='progress')return progressView();if(route==='profile')return intro('profile')+`<article class="alpha-card"><h2>${tr('localProfile')}</h2><p>${tr('localProfileNote')}</p></article>`;if(route==='sync'&&getState().calendarTestSync)return intro('sync')+`<article class="alpha-card"><h2>${tr('localExchange')}</h2><p>${tr('revision')} · ${getState().calendarTestSync.base.revision}</p>${action('exchangeStatus','exchange-status')}</article>`;if(route==='sync')return intro('sync')+`<article class="alpha-card"><h2>${tr(getError()?'localError':'localSaved')}</h2><p class="muted">${tr('revision')}: ${getState().revision}</p><p>${tr('localSyncNote')}</p>${getError()?`<p class="error">${esc(getError())}</p>`:''}<button type="button" class="action-button action-button--secondary" data-route="settings">${tr('settings')}</button></article>`;return null;}
 function mount(){
  updateTimers();
  canvasViewer.mount(document.querySelector('.canvas-viewport'),activeScene);
 }
 let workoutTimer=null;
 function stopWorkoutTimer(){if(workoutTimer!==null){clearInterval(workoutTimer);workoutTimer=null;}}
 function updateTimers(){
  // A timestamp supplies elapsed time; an idle/hidden screen needs no timer.
  const outputs=document.querySelectorAll('[data-workout-elapsed],[data-workout-rest]');
  if(document.hidden||!outputs.length){stopWorkoutTimer();return;}
  const s=getState()?.activeWorkout;if(s?.mobileSessionVersion!==1){stopWorkoutTimer();return;}
  const elapsed=duration(model.workoutElapsed(s)),rest=duration(model.restRemaining(s));
  for(const el of outputs){const value=el.hasAttribute('data-workout-elapsed')?elapsed:rest;if(el.textContent!==value)el.textContent=value;}
  if(s.pausedAt){stopWorkoutTimer();return;}
  if(workoutTimer===null)workoutTimer=setInterval(updateTimers,1000);
 }
 document.addEventListener('visibilitychange',updateTimers);
 window.addEventListener('focus',updateTimers);window.addEventListener('pageshow',updateTimers);window.addEventListener('pagehide',stopWorkoutTimer);
 function workoutError(key){const el=$('workout-error');if(el){el.textContent=tr(key)||getError();el.hidden=false;}}
 async function workoutWrite(change,success){let problem;const ok=await write(s=>{try{change(s);}catch(e){problem=e.message;throw e;}},success);if(!ok&&!dialog.open)workoutError(problem||'saveError');}
 document.addEventListener('input',e=>{
  if(e.target.id==='note-search'){query=e.target.value;$('note-results').innerHTML=noteRows();}
  const row=e.target.closest('[data-workout-set]');if(row){const set=getState().activeWorkout?.sets?.find(s=>s.id===row.dataset.workoutSet);drafts.set(row.dataset.workoutSet,{result:row.querySelector('[data-set-result]').value,load:row.querySelector('[data-set-load]').value,name:set?.name,index:set?.index,unit:set?.unit});}
 });
 document.addEventListener('change',e=>{if(e.target.id==='progress-period'){period=e.target.value;navigate('progress');$('progress-period')?.focus();}});
 // Capture derived Calendar projections before the standalone event editor sees them.
 function projectedEvent(e){const card=e.target.closest('[data-calendar-event]');if(!card?.hasAttribute('data-projected-task'))return;if(e.type==='keydown'&&!['Enter',' '].includes(e.key))return;e.preventDefault();e.stopImmediatePropagation();const id=card.dataset.projectedTask,entry=taskEntry(getState(),id);if(entry?.project)open('projectTask',id,entry.project.id);}
 document.addEventListener('click',projectedEvent,true);document.addEventListener('keydown',projectedEvent,true);
 document.addEventListener('change',e=>{if(testing()&&e.target.id==='desktop-habit-date'&&e.target.validity.valid&&validDay(e.target.value))setHabitDate(e.target.value);});
 document.addEventListener('click',async e=>{
  const valueButton=e.target.closest('[data-test-habit-value]');if(valueButton){if(!busy&&!dialog.open&&!isStale())habitValueEditor(valueButton.dataset.testHabitValue,valueButton.dataset.day);return;}
  const b=e.target.closest('[data-alpha]');if(!b||busy)return;const code=b.dataset.alpha,id=b.dataset.id,project=b.dataset.project;
  if(testing()&&['new-habit','new-note','new-project','new-project-task','new-workout','archive-habit','check-history','trash-note','restore-note','delete-project-task','undo-project-task','plan-workout','start-workout','start-plan','log-set','save-workout-inputs','pause-workout','finish-workout','add-exercise','remove-exercise'].includes(code))return;
  if(code==='test-habit-clear'&&(testing()||getState().workspaceReadOnly?.['habits:'+id]))return beforeAction(()=>write(s=>{const habit=sharedHabit(s,id),date=b.dataset.day,status=valueStatus(s,habit,date);if(!status.supported||!status.eligible||status.kind==='completion')throw Error('alphaReadOnly');(habit.values??={})[date]=0;},()=>dialog.close()));
  if(code==='test-task-completion'&&testing())return beforeAction(()=>write(s=>{if(!allowed('task',id,project,'taskCompletion'))throw Error('alphaReadOnly');const task=s.projects.find(p=>p.id===project)?.tasks.find(t=>t.id===id);if(!task)throw Error('entityMissing');toggleTask(s,id);},()=>dialog.close()));
  if(code==='discard-workout-recovery'){recoveredWorkouts=recoveredWorkouts.filter(r=>r.id!==id);return navigate('sport');}
  const newKinds={'new-habit':'habit','new-note':'note','new-project':'project','new-workout':'workout'};if(newKinds[code])return open(newKinds[code]);
  const editKinds={'edit-habit':'habit','edit-note':'note','edit-project':'project','edit-project-task':'projectTask','edit-workout':'workout','result':'result','open-node':'node'};if(editKinds[code])return open(editKinds[code],id,project||b.dataset.board);
  if(code==='habit-history'){if(dialog.open)return beforeAction(()=>{afterClose=()=>open('habit-history',id);dialog.close();});return open('habit-history',id);}
  if(code==='archive-habit')return beforeAction(()=>write(s=>model.archiveHabit(s,id,new Date(),!s.habits.find(h=>h.id===id).archived),()=>dialog.close()));
  if(code==='check-history')return write(s=>model.checkHabit(s,id,b.dataset.day),()=>{if($('habit-history-content')){$('habit-history-content').innerHTML=historyMarkup(id);dialog.querySelector(`[data-day="${b.dataset.day}"]`)?.focus({preventScroll:true});}});
  if(code==='trash-note'||code==='restore-note')return beforeAction(()=>write(s=>model.trashNote(s,id,new Date(),code==='restore-note'),()=>{if(code==='trash-note')lastTrash=id;else if(lastTrash===id)lastTrash=null;if(dialog.open){afterClose=()=>navigate('notes');dialog.close();}else navigate('notes');}));
  if(code==='toggle-trash'){showTrash=!showTrash;return navigate('notes');}
  if(code==='exchange-status'){const panel=document.getElementById('personal-account')||document.getElementById('calendar-rehearsal');if(panel){panel.open=true;panel.querySelector('summary').focus();}return;}
  if(code==='open-project'){selectedProject=id;return navigate('projects');}if(code==='project-list'){selectedProject=null;return navigate('projects');}
  if(code==='new-project-task')return open('projectTask',null,id);
  if(code==='main-project-task')return beforeAction(()=>write(s=>{const task=s.projects.find(p=>p.id===project).tasks.find(t=>t.id===id);if(!task?.deadline)throw Error('invalid');s.mainTasks[task.deadline]=id;},()=>dialog.close()));
  if(code==='delete-project-task')return beforeAction(()=>write(s=>model.removeProjectTask(s,project,id),()=>dialog.close()));
  if(code==='undo-project-task')return write(model.restoreProjectTask);
  if(code==='add-exercise'){if(dialog.querySelectorAll('[data-exercise]').length>=30)return;$('exercise-rows').insertAdjacentHTML('beforeend',exerciseRow({id:uuid(),name:'',sets:3,target:'8',rest:60,unit:'reps'}));$('exercise-rows').lastElementChild.querySelector('input').focus();return;}
  if(code==='remove-exercise'){b.closest('[data-exercise]').remove();return;}
  if(code==='plan-workout'){if(dialog.open)return beforeAction(()=>{afterClose=()=>open('plan',id);dialog.close();});return open('plan',id);}
  if(code==='start-workout'||code==='start-plan')return beforeAction(()=>workoutWrite(s=>model.startWorkout(s,code==='start-plan'?null:id,uuid(),code==='start-plan'?id:null),()=>{if(dialog.open){afterClose=()=>navigate('sport');dialog.close();}else navigate('sport');}));
  if(code==='log-set'){
   const set=getState().activeWorkout?.sets?.find(s=>s.id===id),row=b.closest('[data-workout-set]');if(!set||!row)return;
   const values={result:row.querySelector('[data-set-result]').value,load:row.querySelector('[data-set-load]').value};
   return workoutWrite(s=>model.logWorkoutSet(s,id,values,new Date(),!set.done),()=>{drafts.delete(id);const target=document.querySelector(`[data-alpha="log-set"][data-id="${CSS.escape(id)}"]`);target?.focus({preventScroll:true});if(!set.done)target?.classList.add('celebrate');});
  }
  if(code==='save-workout-inputs'){const entries=[...drafts];return workoutWrite(s=>model.saveWorkoutInputs(s,entries),()=>{drafts.clear();});}
  if(code==='pause-workout'||code==='finish-workout'){
   if(drafts.size){workoutError('pendingInputs');return;}if(code==='finish-workout')return open('finish',getState().activeWorkout.id);return workoutWrite(model.pauseWorkout);
  }
  if(code==='open-board'){selectedBoard=id;canvasViewer.reset();return navigate('canvas');}if(code==='board-list'){selectedBoard=null;activeScene=null;canvasViewer.reset();return navigate('canvas');}

 });
 return {view,mount,open,habitSection,isOpen:()=>dialog.open,hasDrafts:()=>drafts.size>0||recoveredWorkouts.length>0,dirty};
}
