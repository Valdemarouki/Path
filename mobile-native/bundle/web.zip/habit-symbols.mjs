// The same catalogue is embedded in the Windows renderer. Only the stable key is synced.
const habitSymbols = [
  ['sun', 'M3 16h18M5 20h14M7 16a5 5 0 0 1 10 0M12 3v3M4.5 7.5l2 2m13-2-2 2', ['Morning', 'Утро', 'Mañana', 'Poranek']],
  ['water', 'M12 2.8C10 6 5.5 10.7 5.5 14.3a6.5 6.5 0 0 0 13 0C18.5 10.7 14 6 12 2.8ZM9 15a3.3 3.3 0 0 0 2.1 2.6', ['Water', 'Вода', 'Agua', 'Woda']],
  ['sport', 'M2.7 10v4m18.6-4v4M5 7h3v10H5zM16 7h3v10h-3zM8 11h8m-8 2h8', ['Training', 'Тренировка', 'Entrenamiento', 'Trening']],
  ['book', 'M12 6.4C9.2 4.4 5.5 4 2.8 4.9v13.4c3.1-.8 6.8-.2 9.2 1.6 2.4-1.8 6.1-2.4 9.2-1.6V4.9c-2.7-.9-6.4-.5-9.2 1.5Zm0 0v13.5', ['Reading', 'Чтение', 'Lectura', 'Czytanie']],
  ['walk', 'M14.9 5.2a1.6 1.6 0 1 1 0-3.2 1.6 1.6 0 0 1 0 3.2ZM6 12.2l3-3.6 3.8-.7 2.4 4 3.8 1.2M12.8 7.9l-2.1 6.2 3.4 2.8 1.6 4.1m-5-6.9-2.1 4-3.4 3', ['Walking', 'Прогулка', 'Paseo', 'Spacer']],
  ['focus', 'M8.3 3.5H5a1.5 1.5 0 0 0-1.5 1.5v3.3m12.2-4.8H19A1.5 1.5 0 0 1 20.5 5v3.3m0 7.4V19a1.5 1.5 0 0 1-1.5 1.5h-3.3m-7.4 0H5A1.5 1.5 0 0 1 3.5 19v-3.3M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z', ['Focus', 'Фокус', 'Concentración', 'Skupienie']],
  ['breath', 'M3 9h10a3 3 0 1 0-3-3M2.5 12.5H18a2.8 2.8 0 1 0-2.6-3.9M5 16h8a2.8 2.8 0 1 1-2.7 3.6', ['Breathing', 'Дыхание', 'Respiración', 'Oddech']],
  ['journal', 'M5.5 3.5H18A1.5 1.5 0 0 1 19.5 5v14a1.5 1.5 0 0 1-1.5 1.5H5.5zM8.5 3.5v17M11.5 8.2h4.8m-4.8 3.5h3.2', ['Journal', 'Дневник', 'Diario', 'Dziennik']],
  ['meal', 'M12 7.7c-2.4-1.5-5.8-1.6-7.3.9-1.7 2.8-.1 8 2.5 10.9 1.5 1.8 3 .7 4.8.7s3.3 1.1 4.8-.7c2.6-2.9 4.2-8.1 2.5-10.9-1.5-2.5-4.9-2.4-7.3-.9Zm0 0C12.1 5.2 11.3 3.6 10 2.7m2.2 3.1c.7-2 2.3-3.2 4.5-3.3-.3 2-2 3.5-4.5 3.3Z', ['Nutrition', 'Питание', 'Alimentación', 'Odżywianie']],
  ['moon', 'M20.3 14.2A8.6 8.6 0 0 1 9.8 3.7 8.7 8.7 0 1 0 20.3 14.2Z', ['Sleep', 'Сон', 'Sueño', 'Sen']],
];
const habitSymbolByKey = new Map(habitSymbols.map(row => [row[0], row]));
const habitLegacyPaths = new Map([
  ['habits', 'M20.5 12a8.5 8.5 0 1 1-2.5-6M18 2.5V6h-3.5M8.5 12l2.4 2.4 4.6-4.8'],
  ['check', 'm5 12 4 4L19 6'],
  ['ban', 'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-15 6L18 6'],
  ['move', 'M6 17 10 4h4l4 13M4 20h16M8 12h8'],
  ['spark', 'm12 3 2 6 7 3-7 2-2 7-2-7-7-2 7-3Z'],
  ['target', 'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-4 0a5 5 0 1 1-10 0 5 5 0 0 1 10 0Zm-5-.5v1'],
  ['flag', 'M5 21V3h14l-3 5 3 5H5'],
  ['repeat', 'M20 8A8 8 0 0 0 5 6L3 9m0-5v5h5m-4 7a8 8 0 0 0 15 2l2-3m0 5v-5h-5'],
]);
export const defaultHabitSymbol = 'sun';
export const isHabitSymbol = key => habitSymbolByKey.has(key);

export function habitSymbolSvg(key) {
  const safeKey = isHabitSymbol(key) || habitLegacyPaths.has(key) ? key : 'habits';
  const d = habitSymbolByKey.get(safeKey)?.[1] || habitLegacyPaths.get(safeKey);
  return `<svg class="habit-symbol" data-habit-symbol="${safeKey}" aria-hidden="true" focusable="false" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round"><path d="${d}"/></svg>`;
}

export function habitSymbolPicker(value, language) {
  const index = Math.max(0, ['en', 'ru', 'es', 'pl'].indexOf(language));
  const legend = ['Icon', 'Иконка', 'Icono', 'Ikona'][index];
  const current = ['Current icon', 'Текущая иконка', 'Icono actual', 'Obecna ikona'][index];
  const choices = habitSymbols.map(([key, , labels]) => {
    const label = labels[index];
    return `<label class="habit-symbol-option" title="${label}"><input type="radio" name="habitIcon" value="${key}" aria-label="${label}" ${key === value ? 'checked' : ''}><span class="habit-symbol-tile">${habitSymbolSvg(key)}</span><span class="habit-symbol-caption" aria-hidden="true">${label}</span></label>`;
  }).join('');
  return `<div class="habit-symbol-picker" role="radiogroup" aria-label="${legend}" data-no-translate><span class="habit-symbol-legend" aria-hidden="true">${legend}</span>${isHabitSymbol(value) ? '' : `<span class="habit-symbol-previous" aria-hidden="true">${habitSymbolSvg(value)} ${current}</span>`}<div class="habit-symbol-grid">${choices}</div></div>`;
}
