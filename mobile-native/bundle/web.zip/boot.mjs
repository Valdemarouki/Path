import {installMediaStorage} from './media-store.mjs';
import {seed,migrate,validate,STORAGE_KEY} from './model.mjs';
import {apply} from './personal-model.mjs';
const marker='path-account:current',shell=document.querySelector('#personal-account');
const text=shell.querySelector('output'),login=shell.querySelector('form'),logout=shell.querySelector('[data-logout]');
const onlineEntry=location.pathname.startsWith('/open/');
const entryPath=onlineEntry?'/open/':'/app/';
if(onlineEntry)login.action='/auth/start?entry=open';
const messages={LOGIN_REQUIRED:'Для обмена войдите в свой аккаунт Path.',PROFILE_CHANGED:'Аккаунт изменился. Откройте его заново.',ACCOUNT_NOT_ENABLED:'Для аккаунта требуется включённая полная синхронизация на ПК и доступ к мобильному обмену.',SERVICE_NOT_READY:'Сервис мобильного обмена ещё не подключён к базе Path.',SAVE_REJECTED:'Сервер отклонил правку. Она сохранена на устройстве.',LOCAL_WRITE:'Не удалось сохранить изменения на устройстве.',INVALID_SNAPSHOT:'Получена неподходящая версия данных.',STALE:'Данные изменились в другой вкладке. Повторяем обмен.'};
const describe=e=>messages[e.message]||'Сервер недоступен. Локальные правки сохраняются до подключения.';
async function boot(){
 let who,response;
 const remembered=localStorage.getItem(marker);
 try{
  response=await fetch('/api/session',{cache:'no-store',redirect:'error',signal:AbortSignal.timeout(8000)});
 }catch{
  who=JSON.parse(remembered||'null');
  if(!who)throw Error('UNAVAILABLE');
 }
 if(response){
  if(response.ok)who=await response.json();
  else if(response.status!==401)throw Error(response.status===403?'PROFILE_CHANGED':'UNAVAILABLE');
 }
 if(localStorage.getItem(marker)!==remembered){location.reload();return;}
 if(response?.status===401){
  localStorage.removeItem(marker);document.body.dataset.account='locked';
  text.textContent=location.search?'Вход не завершён. Попробуйте ещё раз.':'Войдите в существующий аккаунт Path.';
  return;
 }
 if(!/^[0-9a-f]{64}$/.test(who.profile))throw Error('PROFILE_CHANGED');
 const prefix='path-account:'+who.profile+':';
 localStorage.setItem(marker,JSON.stringify(who));
 function guard(){if(JSON.parse(localStorage.getItem(marker)||'null')?.profile!==who.profile)throw Error('PROFILE_CHANGED');}
 window.addEventListener('storage',e=>{if(e.key===marker||e.key===null){try{guard();}catch{location.reload();}}});
 const storage={getItem:k=>{guard();return localStorage.getItem(prefix+k);},setItem:(k,v)=>{guard();localStorage.setItem(prefix+k,v);},removeItem:k=>{guard();localStorage.removeItem(prefix+k);}};
 await installMediaStorage(storage,'path-account-media:'+who.profile);
 window.addEventListener('storage',async e=>{
  if(!e.isTrusted||!e.key?.startsWith(prefix))return;
  try{await storage.refreshMedia();}finally{window.dispatchEvent(new StorageEvent('storage',{key:e.key.slice(prefix.length),storageArea:localStorage}));}
 });
 const request=async(url,body)=>{
  guard();const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-Path-Profile':who.profile},body:JSON.stringify(body),cache:'no-store',redirect:'error',signal:AbortSignal.timeout(24000)});
  const value=await r.json();guard();
  if(!r.ok){
   if(['PROFILE_CHANGED','LOGIN_REQUIRED'].includes(value.error)){localStorage.removeItem(marker);location.replace(entryPath);}
   throw Error(value.error);
  }
  return value;
 };
 globalThis.pathPersonal={profile:who.profile,email:who.email,request,describe};globalThis.personalStorage=storage;
 shell.querySelector('summary').textContent=who.email||'Личный аккаунт';logout.hidden=false;login.hidden=true;
 logout.onclick=async()=>{try{await request('/auth/logout',{});localStorage.removeItem(marker);location.replace(entryPath);}catch(e){text.textContent=describe(e);}};
 if(!navigator.locks)throw Error('LOCAL_WRITE');
 await navigator.locks.request(STORAGE_KEY,async()=>{
  if(storage.getItem(STORAGE_KEY)!==null)return;
  const head=await request('/api/read',{p_known:null});if(!head.active||!head.payload)throw Error('INVALID_SNAPSHOT');
  const clean=seed();clean.homeTasks=[];clean.habits=[];clean.events=[];
  const s=migrate(clean);apply(s,head.payload);s.personalSync={owner:who.profile,base:{revision:head.revision,payload:head.payload}};
  await storage.writeCheckpoint(STORAGE_KEY,JSON.stringify(validate(s)));
 });
 document.body.dataset.account='ready';await import('./app.mjs');
}
boot().catch(e=>{
 text.textContent=describe(e);shell.open=true;
 const retry=document.createElement('button');
 retry.type='button';retry.textContent='Повторить';retry.onclick=()=>location.reload();shell.append(retry);
});
if('serviceWorker' in navigator){
 if(onlineEntry){
  navigator.serviceWorker.getRegistration('/app/').then(registration=>{
   if(registration?.scope===location.origin+'/app/')return registration.update();
  }).catch(()=>{});
 }else{
  navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).catch(()=>{});
 }
}
