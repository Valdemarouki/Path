import {installMediaStorage} from './media-store.mjs';
import {seed,migrate,validate,STORAGE_KEY} from './model.mjs';
import {apply} from './personal-model.mjs';
const marker='path-account:current',shell=document.querySelector('#personal-account');
const text=shell.querySelector('output'),login=shell.querySelector('form'),logout=shell.querySelector('[data-logout]');
const onlineEntry=location.pathname.startsWith('/open/');
const entryPath=onlineEntry?'/open/':'/app/';
if(onlineEntry)login.action='/auth/start?entry=open';
const messages={LOGIN_REQUIRED:'Для обмена войдите в свой аккаунт Path.',PROFILE_CHANGED:'Аккаунт изменился. Откройте его заново.',ACCOUNT_NOT_ENABLED:'Для аккаунта требуется включённая полная синхронизация на ПК и доступ к мобильному обмену.',SERVICE_NOT_READY:'Сервис мобильного обмена ещё не подключён к базе Path.',SAVE_REJECTED:'Сервер отклонил правку. Она сохранена на устройстве.',LOCAL_WRITE:'Не удалось сохранить изменения на устройстве.',INVALID_SNAPSHOT:'Получена неподходящая версия данных.',STALE:'Данные изменились в другой вкладке. Повторяем обмен.'};
const describe=e=>messages[e.message]||'Сервер недоступен. Локальные правки сохраняются до подключения.';
async function boot(){
 let who,response;
 const remembered=localStorage.getItem(marker);
 try{
  response=await fetch('/api/session',{cache:'no-store',redirect:'error',signal:AbortSignal.timeout(8000)});
 }catch{
  who=JSON.parse(remembered||'null');
  if(!who)throw Error('UNAVAILABLE');
 }
 if(response){
  if(response.ok)who=await response.json();
  else if(response.status!==401)throw Error(response.status===403?'PROFILE_CHANGED':'UNAVAILABLE');
 }
 if(localStorage.getItem(marker)!==remembered){location.reload();return;}
 if(response?.status===401){
  localStorage.removeItem(marker);document.body.dataset.account='locked';
  text.textContent=location.search?'Вход не завершён. Попробуйте ещё раз.':'Войдите в существующий аккаунт Path.';
  return;
 }
 if(!/^[0-9a-f]{64}$/.test(who.profile))throw Error('PROFILE_CHANGED');
 const prefix='path-account:'+who.profile+':';
 localStorage.setItem(marker,JSON.stringify(who));
 function guard(){if(JSON.parse(localStorage.getItem(marker)||'null')?.profile!==who.profile)throw Error('PROFILE_CHANGED');}
 window.addEventListener('storage',e=>{if(e.key===marker||e.key===null){try{guard();}catch{location.reload();}}});
 const storage={getItem:k=>{guard();return localStorage.getItem(prefix+k);},setItem:(k,v)=>{guard();localStorage.setItem(prefix+k,v);},removeItem:k=>{guard();localStorage.removeItem(prefix+k);}};
 await installMediaStorage(storage,'path-account-media:'+who.profile);
 window.addEventListener('storage',async e=>{
  if(!e.isTrusted||!e.key?.startsWith(prefix))return;
  try{await storage.refreshMedia();}finally{window.dispatchEvent(new StorageEvent('storage',{key:e.key.slice(prefix.length),storageArea:localStorage}));}
 });
 const request=async(url,body)=>{
  guard();const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-Path-Profile':who.profile},body:JSON.stringify(body),cache:'no-store',redirect:'error',signal:AbortSignal.timeout(24000)});
  const value=await r.json();guard();
  if(!r.ok){
   if(['PROFILE_CHANGED','LOGIN_REQUIRED'].includes(value.error)){localStorage.removeItem(marker);location.replace(entryPath);}
   throw Error(value.error);
  }
  return value;
 };
 globalThis.pathPersonal={profile:who.profile,email:who.email,request,describe};globalThis.personalStorage=storage;
 shell.querySelector('summary').textContent=who.email||'Личный аккаунт';logout.hidden=false;login.hidden=true;
 logout.onclick=async()=>{try{await request('/auth/logout',{});localStorage.removeItem(marker);location.replace(entryPath);}catch(e){text.textContent=describe(e);}};
 if(!navigator.locks)throw Error('LOCAL_WRITE');
 let sharedOnly=false;
 await navigator.locks.request(STORAGE_KEY,async()=>{
  if(storage.getItem(STORAGE_KEY)!==null)return;
  let head;
  try{head=await request('/api/read',{p_known:null});}catch(e){if(e.message!=='ACCOUNT_NOT_ENABLED')throw e;}
  if(!head||head.active===false){sharedOnly=true;return;}
  if(!head.payload)throw Error('INVALID_SNAPSHOT');
  const clean=seed();clean.homeTasks=[];clean.habits=[];clean.events=[];
  const s=migrate(clean);apply(s,head.payload);s.personalSync={owner:who.profile,base:{revision:head.revision,payload:head.payload}};
  await storage.writeCheckpoint(STORAGE_KEY,JSON.stringify(validate(s)));
 });
 if(sharedOnly){
  const lang=()=>navigator.language.slice(0,2);
  PathSharedLibrary.mount({rpc:(action,args)=>request('/api/path-sharing',{action,args}),local:()=>[],mobile:true,language:lang,css:":host{display:block;color:inherit;font:inherit}.panel{border:1px solid #454549;border-radius:14px;padding:14px;margin:16px 0;background:#18191b}\n h2,h3,p{margin:.4em 0}h2{font-size:1.3em}h3{font-size:1.05em}.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:9px 0}\n button,input,textarea,select{color:inherit;font:inherit;background:#242527;border:1px solid #525357;border-radius:8px;padding:8px 11px;max-width:100%;box-sizing:border-box}\n button{cursor:pointer}button:disabled{opacity:.55}button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible,summary:focus-visible{outline:2px solid currentColor}\n label{display:grid;gap:4px;margin:8px 0}input,textarea{min-width:0}textarea{min-height:65px}small,code{overflow-wrap:anywhere;color:#b7b7b8}code{user-select:all}\n dialog{color:#eee;background:#171819;border:1px solid #515154;border-radius:16px;width:min(690px,94vw);max-height:85dvh;box-sizing:border-box;overflow:auto;padding:20px}dialog::backdrop{background:#000a}\n .item{display:block;width:100%;text-align:left;margin:6px 0}.error{color:#f5cebc}svg{display:block;width:100%;height:clamp(150px,35vh,320px);background:#111213;border-radius:10px}summary{cursor:pointer}\n @media(max-width:600px){button,select,input{min-height:44px}dialog{padding:14px}}\n.draggable{cursor:grab;touch-action:none}.draggable:active{cursor:grabbing}\n.path-shared-mark{display:inline-flex;align-items:center;vertical-align:middle;gap:5px;margin-inline-start:8px;padding:2px 7px;border:1px solid #565656;border-radius:99px;background:#282828;color:#ededed;font:500 12px/18px system-ui,sans-serif;white-space:nowrap}\n.path-shared-mark svg{width:15px;height:15px;background:none;border-radius:0;fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}\n.projects-library .project-card-open>.path-shared-mark{position:absolute;top:13px;right:50px;margin:0;pointer-events:none}\n.projects-library [data-shared-card] .path-shared-mark{right:15px}\n.projects-library [data-shared-card] .project-card-open{padding-top:23px}\n.alpha-card[data-alpha=\"open-project\"]>.path-shared-mark,.alpha-card[data-alpha=\"open-board\"]>.path-shared-mark{position:absolute;top:13px;right:15px;pointer-events:none}\n.alpha-card[data-alpha=\"open-project\"]:has(>.path-shared-mark),.alpha-card[data-alpha=\"open-board\"]:has(>.path-shared-mark){padding-top:35px}\n.item .path-shared-mark{float:inline-end}details>summary{min-height:32px}.row>span{overflow-wrap:anywhere}\n@media(max-width:600px){dialog[open]{position:fixed;inset:auto 0 0;margin:0 auto;max-height:86dvh;width:100%;border-radius:16px 16px 0 0;padding-bottom:max(16px,env(safe-area-inset-bottom))}}\n\n.cursor-surface{position:relative;isolation:isolate;overflow:hidden;border-radius:10px}\n.cursor-surface .cursor-overlay{position:absolute;inset:0;width:100%;height:100%;background:transparent;border:0;border-radius:0;pointer-events:none;overflow:hidden}\n.cursor-surface .cursor-board{display:block;touch-action:pan-y}\n.cursor-overlay .cursor-tip{fill:#fafafa;stroke:#151515;stroke-width:1.4;stroke-linejoin:round}\n.cursor-overlay rect{fill:#fafafa;stroke:#282828;stroke-width:1}\n.cursor-overlay text{font:600 12px system-ui,sans-serif;fill:#151515}\n.cursor-overlay [data-tone=\"1\"] rect,.cursor-overlay [data-tone=\"1\"] .cursor-tip{fill:#484848;stroke:#efefef}\n.cursor-overlay [data-tone=\"1\"] text{fill:#fff}\n.cursor-overlay [data-tone=\"2\"] rect,.cursor-overlay [data-tone=\"2\"] .cursor-tip{fill:#c5c5c5}\n.cursor-settings{margin:8px 0;color:#dadada;font-size:13px}\n.cursor-settings label{display:flex;align-items:center;gap:8px}\n.cursor-settings input[type=\"checkbox\"]{min-height:0}\n.cursor-settings summary{min-height:32px;align-content:center}\n.cursor-surface .cursor-overlay.cursor-hidden{display:none}\n"});
  text.textContent='';shell.open=true;
  for(const kind of ['project','canvas']){
   const section=document.createElement('section'),title=document.createElement('h2'),library=document.createElement('path-shared-library');
   title.textContent=kind==='canvas'?'Canvas':({ru:'Проекты',es:'Proyectos',pl:'Projekty'}[lang()]||'Projects');
   library.setAttribute('kind',kind);section.append(title,library);shell.append(section);
  }
  return;
 }
 document.body.dataset.account='ready';await import('./app.mjs');
}
boot().catch(e=>{
 text.textContent=describe(e);shell.open=true;
 const retry=document.createElement('button');
 retry.type='button';retry.textContent='Повторить';retry.onclick=()=>location.reload();shell.append(retry);
});
if('serviceWorker' in navigator){
 if(onlineEntry){
  navigator.serviceWorker.getRegistration('/app/').then(registration=>{
   if(registration?.scope===location.origin+'/app/')return registration.update();
  }).catch(()=>{});
 }else{
  navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).catch(()=>{});
 }
}
