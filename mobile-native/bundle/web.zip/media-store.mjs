// Large image strings are immutable. Write their contents before atomically replacing
// the localStorage checkpoint, so a failed write leaves the old checkpoint readable.
const marker = 'path-media-v1:';
const imageToken = /"(data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]{1024,})"/g;
const stateKey = 'path-mobile-alpha-v1';

export async function installMediaStorage(storage, databaseName='path-calendar-rehearsal-mobile-media') {
  const {getItem, setItem} = storage;
  const contents = new Map(), hashes = new Map();
  let database;
  async function db() {
    if (!database) database = await new Promise((resolve,reject) => {
      const request = indexedDB.open(databaseName,1);
      request.onupgradeneeded = () => request.result.createObjectStore('images');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    return database;
  }
  async function transaction(mode, schedule) {
    const connection = await db();
    await new Promise((resolve,reject) => {
      const tx = connection.transaction('images',mode);
      tx.oncomplete = resolve;
      tx.onabort = () => reject(tx.error || Error('Image storage transaction failed'));
      schedule(tx.objectStore('images'));
    });
  }
  function references(raw) {
    return new Set(raw?.startsWith(marker) ? JSON.parse(raw.slice(marker.length)).filter((_,i)=>i%2) : []);
  }
  async function hydrate() {
    const raw = getItem(stateKey);
    const active = references(raw);
    for (const [hash,image] of contents) {
      if (!active.has(hash)) { contents.delete(hash); hashes.delete(image); }
    }
    const missing = [...active].filter(hash => !contents.has(hash));
    if (!missing.length) return;
    await transaction('readonly', store => {
      for (const hash of missing) {
        const request = store.get(hash);
        request.onsuccess = () => {
          if (typeof request.result === 'string') {
            contents.set(hash,request.result);
            hashes.set(request.result,hash);
          }
        };
      }
    });
    if (getItem(stateKey) !== raw) return hydrate();
    for (const hash of missing) if (!contents.has(hash)) throw Error('Missing saved photo');
  }
  await hydrate();
  storage.refreshMedia = hydrate;
  storage.getItem = key => {
    const raw = getItem(key);
    if (key !== stateKey || !raw?.startsWith(marker)) return raw;
    return JSON.parse(raw.slice(marker.length)).map((part,i) => {
      if (i%2 === 0) return part;
      if (!contents.has(part)) throw Error('conflict');
      return '"' + contents.get(part) + '"';
    }).join('');
  };
  storage.writeCheckpoint = async (key,raw) => {
    const initial = getItem(key);
    const prior = references(initial);
    const parts = raw.split(imageToken);
    const added = new Map();
    for (let i=1; i<parts.length; i+=2) {
      const image = parts[i];
      let hash = hashes.get(image) || added.get(image);
      if (!hash) {
        const bytes = await crypto.subtle.digest('SHA-256',new TextEncoder().encode(image));
        hash = Array.from(new Uint8Array(bytes),byte=>byte.toString(16).padStart(2,'0')).join('');
      }
      if (!prior.has(hash)) added.set(image,hash);
      parts[i] = hash;
    }
    if (added.size) {
      await transaction('readwrite', store => {
        for (const [image,hash] of added) store.put(image,hash);
      });
      for (const [image,hash] of added) {
        hashes.set(image,hash);
        contents.set(hash,image);
      }
    }
    const retained = new Set(parts.filter((_,i) => i%2));
    let active;
    try {
      if (getItem(key) !== initial) throw Error('conflict');
      setItem(key,parts.length === 1 ? raw : marker + JSON.stringify(parts));
      active = retained;
    } finally {
      // The manifest is the commit point. After a failed write keep the old media.
      active ??= references(getItem(key));
      const unused = [...contents.keys()].filter(hash => !active.has(hash));
      if (unused.length) {
        try {
          await transaction('readwrite', store => { for (const hash of unused) store.delete(hash); });
          for (const hash of unused) {
            hashes.delete(contents.get(hash));
            contents.delete(hash);
          }
        } catch { /* The committed checkpoint remains valid if deletion has to wait. */ }
      }
    }
  };
}
