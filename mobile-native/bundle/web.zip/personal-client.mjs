import {apply,projection,reconcile,equal} from './personal-model.mjs';
export function startPersonalSync({read,write,busy,prepare}){
 const box=document.querySelector('#personal-account'),status=box.querySelector('output'),buttons=box.querySelector('.choices');
 let active=false,displayed=null,choice=null,rejectedId=null;
 const message=t=>{if(status.textContent!==t)status.textContent=t;};
 const api=window.pathPersonal.request;
 async function change(fn){
  if(!await write(fn))throw Error('LOCAL_WRITE');
 }
 function adopt(s,head,content){apply(s,content);s.personalSync={base:head,owner:pathPersonal.profile};}
 function showConflict(names){
  message('Есть разные правки одной записи: '+names.join(', '));buttons.hidden=false;
 }
 async function sync(){
  if(active||document.hidden||busy())return;
  active=true;
  try{
   prepare();
   const journal=read().personalSync;
   if(!journal||journal.owner!==pathPersonal.profile)throw Error('PROFILE_CHANGED');
   if(journal.pending){
    const job=journal.pending;
    let response;
    try{
     if(rejectedId===job.id)throw Error('SAVE_REJECTED');
     response=await api('/api/push',{p_expected:job.expected,p_operation:job.id,p_payload:job.payload});}
    catch(error){
     // A validation error is definitive. A lost response must replay the same operation.
     if(error.message==='SAVE_REJECTED')rejectedId=job.id;
     if(rejectedId===job.id&&!busy()&&!equal(projection(read(),journal.base.payload),job.payload))await change(s=>{
      if(s.personalSync.pending?.id===job.id&&!equal(projection(s,s.personalSync.base.payload),job.payload))delete s.personalSync.pending;
     });
     throw error;
    }
    if(!response.active||!response.payload||!Number.isSafeInteger(response.revision)||typeof response.ok!=='boolean')throw Error('INVALID_SNAPSHOT');
    if(busy())return;
    await change(s=>{
     if(s.personalSync.pending?.id!==job.id)throw Error('STALE');
     const base=s.personalSync.base,local=projection(s,base.payload);
     if(response.ok){
      // Changes made on the device during the request stay in the checkpoint.
      const merged=reconcile(job.payload,local,response.payload,'local');
      adopt(s,{revision:response.revision,payload:response.payload},merged.result);
     }else{s.personalSync.remote={revision:response.revision,payload:response.payload};delete s.personalSync.pending;}
    });
   }
   const current=read().personalSync,base=current.base;
   const known=current.remote||base;
   const reply=await api('/api/read',{p_known:known.revision});
   if(!reply.active||(!reply.payload&&reply.revision!==known.revision))throw Error('INVALID_SNAPSHOT');
   const head=reply.payload?reply:known;
   if(!Number.isSafeInteger(head.revision)||head.revision<base.revision)throw Error('INVALID_SNAPSHOT');
   if(busy())return;
   const remote=head.payload||base.payload,local=projection(read(),base.payload);
   const resolution=choice?.revision===head.revision&&equal(choice.local,local)?choice.value:null;
   const merge=reconcile(base.payload,local,remote,resolution);
   if(merge.conflicts.length&&!resolution){displayed={revision:head.revision,local};choice=null;showConflict(merge.conflicts);return;}
   if(head.revision!==base.revision||current.remote||!equal(local,remote)){
    await change(s=>{
     if(s.personalSync.base.revision!==base.revision||s.personalSync.pending||!equal(projection(s,base.payload),local))throw Error('STALE');
     adopt(s,{revision:head.revision,payload:remote},merge.result);
     if(!equal(merge.result,remote))s.personalSync.pending={id:crypto.randomUUID(),expected:head.revision,payload:merge.result};
    });
   }
   choice=null;displayed=null;buttons.hidden=true;
   if(read().personalSync.pending){message('Правки сохранены на телефоне. Отправляем…');setTimeout(sync,0);}
   else message('Синхронизировано · версия '+head.revision);
  }catch(e){message(pathPersonal.describe(e));}
  finally{active=false;}
 }
 buttons.onclick=e=>{if(['local','remote'].includes(e.target.value)){choice={...displayed,value:e.target.value};sync();}};
 box.querySelector('[data-exchange]').onclick=()=>{rejectedId=null;sync();};
 window.addEventListener('online',sync);window.addEventListener('pageshow',sync);document.addEventListener('visibilitychange',sync);
 setInterval(sync,4500);sync();
}
