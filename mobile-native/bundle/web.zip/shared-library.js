// Shared documents are edited outside the private checkpoint and its sync and Undo queues.
(() => {
 const labels={
  shared:['Shared with people','Общие с другими людьми','Compartido','Udostępnione'],
  account:['My Path ID','Мой Path ID','Mi ID de Path','Mój ID Path'],
  share:['Create shared version','Создать общую версию','Crear versión compartida','Utwórz wspólną wersję'],
  select:['Choose a local item','Выберите личный объект','Elige un elemento local','Wybierz lokalny element'],
  own:['Owner','Владелец','Propietario','Właściciel'], member:['Editor','Редактор','Editor','Edytor'],
  view:['View only','Только просмотр','Solo lectura','Tylko odczyt'],
  members:['People with access','Участники','Personas con acceso','Osoby z dostępem'],
  invite:['Add account','Добавить аккаунт','Añadir cuenta','Dodaj konto'], id:['Participant’s Path ID','Path ID участника','ID de Path del participante','ID Path uczestnika'],
  remove:['Remove access','Отозвать доступ','Retirar acceso','Odbierz dostęp'],leave:['Leave','Выйти из общего объекта','Salir','Opuść'],
  close:['Close','Закрыть','Cerrar','Zamknij'],save:['Save','Сохранить','Guardar','Zapisz'],cancel:['Cancel','Отмена','Cancelar','Anuluj'],
  title:['Title','Название','Título','Nazwa'],body:['Text','Текст','Texto','Tekst'],status:['Status','Статус','Estado','Status'],
  planned:['Planned','Запланировано','Planificado','Zaplanowane'],progress:['In progress','В работе','En curso','W toku'],done:['Done','Готово','Hecho','Gotowe'],
  rename:['Rename','Переименовать','Cambiar nombre','Zmień nazwę'],addTask:['Add task','Добавить задачу','Añadir tarea','Dodaj zadanie'],
  addCard:['Add text card','Добавить текст','Añadir texto','Dodaj tekst'],edit:['Edit','Изменить','Editar','Edytuj'],
  photo:['Photo','Фотография','Foto','Zdjęcie'],
  details:['Details','Подробнее','Detalles','Szczegóły'],draft:['Your edit','Ваша правка','Tu cambio','Twoja zmiana'],
  conflict:['This field changed. Your draft is below. Cancel to see the latest version.','Это поле изменилось. Ваш черновик сохранён в форме. Нажмите «Отмена», чтобы увидеть последнюю версию.','Este campo cambió. Cancela para ver la última versión.','To pole się zmieniło. Anuluj, aby zobaczyć najnowszą wersję.'],
  denied:['Access removed','Доступ отозван','Acceso revocado','Odebrano dostęp'],
  paid:['An active owner subscription is required to share or edit.','Для общего доступа и редактирования нужна действующая подписка владельца.','Se requiere la suscripción del propietario para compartir o editar.','Udostępnianie i edycja wymagają aktywnej subskrypcji właściciela.'],
  invalid:['Check the selected data','Проверьте выбранные данные','Revisa los datos','Sprawdź dane'],
  unknown:['Account not found. Check the Path ID.','Аккаунт не найден. Проверьте Path ID.','Cuenta no encontrada. Revisa el ID.','Nie znaleziono konta. Sprawdź ID.'],
  network:['Could not reach the sharing service. Try again.','Не удалось связаться с сервисом. Попробуйте ещё раз.','No se pudo conectar. Inténtalo de nuevo.','Nie można połączyć się z usługą. Spróbuj ponownie.'],
  retry:['Try again','Повторить','Reintentar','Spróbuj ponownie']
 };
 const el=(tag,text)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;return n;};
 const btn=(text,click)=>{const b=el('button',text);b.type='button';b.onclick=click;return b;};
 const row=(...nodes)=>{const n=el('div');n.className='row';n.append(...nodes);return n;};
 const field=(text,node)=>{const n=el('label',text);n.append(node);return n;};

 function diagram(board,select,move){
  const ns='http://www.w3.org/2000/svg';
  const make=(tag,attrs)=>{const n=document.createElementNS(ns,tag);for(const [key,value] of Object.entries(attrs))n.setAttribute(key,String(value));return n;};
  const bounded=(n,fallback)=>Number.isFinite(n)?Math.min(100000,Math.max(-100000,n)):fallback;
  const boxes=board.nodes.map(n=>({id:n.id,x:bounded(n.x,0),y:bounded(n.y,0),w:Math.max(40,bounded(n.width,240)),h:Math.max(30,bounded(n.height,140)),n}));
  if(!boxes.length)return el('div');
  const left=Math.min(...boxes.map(b=>b.x))-16,top=Math.min(...boxes.map(b=>b.y))-16;
  const svg=make('svg',{viewBox:[left,top,Math.max(...boxes.map(b=>b.x+b.w))-left+16,Math.max(...boxes.map(b=>b.y+b.h))-top+16].join(' '),'aria-hidden':'true'});
  const byId=new Map(boxes.map(b=>[b.id,b]));
  for(const edge of board.edges){const a=byId.get(edge.from),b=byId.get(edge.to);if(a&&b)svg.append(make('line',{x1:a.x+a.w/2,y1:a.y+a.h/2,x2:b.x+b.w/2,y2:b.y+b.h/2,stroke:'#999','stroke-width':2}));}
  for(const b of boxes){
   const g=make('g',{});g.append(make('rect',{x:b.x,y:b.y,width:b.w,height:b.h,rx:8,fill:'#26272a',stroke:'#8d8e92'}));
   if(typeof b.n.image==='string' && /^data:image\/(png|jpeg|webp);base64,[a-z\d+/]+=*$/i.test(b.n.image)){
    g.append(make('image',{x:b.x,y:b.y,width:b.w,height:b.h,href:b.n.image}));
   }else{const t=make('text',{x:b.x+8,y:b.y+22,fill:'#eee','font-size':14});t.textContent=String(b.n.title||b.n.body||'').slice(0,36);g.append(t);}
   if(move){
    g.classList.add('draggable');
    g.onpointerdown=e=>{
     if(e.button!==0 || !e.isPrimary)return;
     const matrix=svg.getScreenCTM();if(!matrix)return;
     const inverse=matrix.inverse(),point=ev=>new DOMPoint(ev.clientX,ev.clientY).matrixTransform(inverse);
     const start=point(e);let dragged=false;
     g.setPointerCapture(e.pointerId);
     g.onpointermove=ev=>{
      const at=point(ev);
      if(Math.hypot(ev.clientX-e.clientX,ev.clientY-e.clientY)>3)dragged=true;
      if(dragged)g.setAttribute('transform',`translate(${at.x-start.x} ${at.y-start.y})`);
     };
     const finish=ev=>{
      g.onpointerup=g.onpointermove=g.onpointercancel=null;g.removeAttribute('transform');
      if(ev.type==='pointercancel')return;
      if(!dragged){select(b.n);return;}
      const at=point(ev);move(b.n,Math.round(b.x+at.x-start.x),Math.round(b.y+at.y-start.y));
     };
     g.onpointerup=g.onpointercancel=finish;
    };
   }else g.onclick=()=>select(b.n);
   svg.append(g);
  }
  return svg;
 }
 function mount({rpc,local,mobile=false,language,css,cssUrl}){
  if(!rpc || !globalThis.customElements || customElements.get('path-shared-library'))return;
  const sheet=()=>{if(!cssUrl)return el('style',css);const n=el('link');n.rel='stylesheet';n.href=cssUrl;return n;};
  const t=k=>labels[k][{ru:1,es:2,pl:3}[language?.()]||0];
  function message(e){const code=String(e?.message||e);for(const [key,value] of Object.entries({SHARE_DENIED:'denied',SHARE_CONFLICT:'conflict',SHARE_INVALID:'invalid',SHARE_ACCOUNT:'unknown',SHARE_SUBSCRIPTION:'paid'}))if(code.includes(key))return t(value);return t('network');}
  let activeDialog;
  function open(initial,notify){
   if(activeDialog?.open)return;
   const host=el('div');document.body.append(host);const shadow=host.attachShadow({mode:'open'}),d=el('dialog');
   shadow.append(sheet(),d);let current=initial,editing=null,busy=false,epoch=0,stopped=false,peopleOpen=false,polling=false,needsPaint=false;
   const note=el('p');note.setAttribute('role','status');note.className='error';
   const kill=()=>{activeDialog=null;stopped=true;clearInterval(timer);host.remove();notify();};
   d.onclose=kill;
   function fail(e){
    if(stopped)return;
    if(String(e.message).includes('SHARE_DENIED')){current=null;editing=null;clearInterval(timer);paint();}
    note.textContent=message(e);
   }
   async function poll(){
    if(busy||polling||stopped||!current||document.hidden)return;const seq=epoch;polling=true;
    try{const latest=await rpc('get',{id:current.id,revision:current.revision});
     if(seq!==epoch||stopped||busy)return;
     if(latest.revision!==current.revision||latest.writable!==current.writable||JSON.stringify(latest.editors)!==JSON.stringify(current.editors)){
      current={...current,...latest};needsPaint=true;
      if(editing&&!current.writable)note.textContent=t('paid');
     }
     if(needsPaint&&!editing&&!shadow.activeElement?.matches('input,textarea,select'))paint();
    }catch(e){if(seq===epoch&&!busy)fail(e);}finally{polling=false;}
   }
   async function run(fn){
    if(busy||stopped)return;busy=true;epoch++;note.textContent='';d.setAttribute('aria-busy','true');
    try{await fn();}catch(e){fail(e);}finally{busy=false;d.removeAttribute('aria-busy');}
   }
   async function applyEdit({base,id,adding=false,renaming=false,canvas,changes}){
    for(let attempt=0;attempt<3;attempt++){
     const head=await rpc('get',{id:current.id});current=head;
     if(!head.writable)throw Error('SHARE_SUBSCRIPTION');
     const doc=structuredClone(head.document),list=canvas?doc.nodes:doc.tasks;
     let target=renaming?doc:list.find(r=>r.id===id);
     if(adding&&!target){target=canvas?{id,kind:'text',width:240,height:140}:{id,status:'planned'};list.push(target);}
     else if(!target || Object.keys(changes).some(k=>target[k]!==base[k] && target[k]!==changes[k]))throw Error('SHARE_CONFLICT');
     Object.assign(target,changes);
     try{current=await rpc('save',{id:head.id,revision:head.revision,document:doc});return;}
     catch(err){if(!String(err.message).includes('SHARE_CONFLICT')||attempt===2)throw err;}
    }
   }
   function edit(item=null,adding=false,renaming=false){
    const canvas=current.kind==='canvas', base=structuredClone(item||{}), id=adding?crypto.randomUUID():item?.id;
    const editable=current.writable && !(mobile&&canvas);
    editing={};d.replaceChildren(el('h2',renaming?t('rename'):editable?t('edit'):t('details')));
    const form=el('form'), inputs={};
    const make=(key,capt,value,type='text')=>{
     const n=el(type==='textarea'?'textarea':type==='status'?'select':'input');
     if(type==='status')for(const k of new Set(['planned','progress','done',value].filter(Boolean))){const o=el('option',labels[k]?t(k):k);o.value=k;n.append(o);}
     if(n.tagName==='INPUT')n.type=type;
     n.value=value??'';n.disabled=!editable;n.name=key;inputs[key]=n;form.append(field(capt,n));return n;
    };
    if(renaming){base.name=current.document.name;make('name',t('title'),base.name).required=true;}
    else{
     make('title',t('title'),base.title).required=!canvas;
     if(canvas){make('body',t('body'),base.body,'textarea');make('x','X',base.x??0,'number');make('y','Y',base.y??0,'number');}
     else make('status',t('status'),base.status||'planned','status');
    }
    const original=Object.fromEntries(Object.entries(inputs).map(([k,n])=>[k,n.value]));
    const cancel=btn(editable?t('cancel'):t('close'),()=>{editing=null;note.textContent='';paint();});const actions=row(cancel);
    if(editable){const save=el('button',t('save'));save.type='submit';actions.prepend(save);}
    form.append(actions,note);d.append(form);note.textContent='';Object.values(inputs)[0].focus();
    form.onsubmit=e=>{e.preventDefault();run(async()=>{
     const changes={};
     for(const [key,input] of Object.entries(inputs)){
      if(adding||input.value!==original[key])changes[key]=input.type==='number'?Number(input.value):input.value;
     }
     if(Object.keys(changes).length){
      await applyEdit({base,id,adding,renaming,canvas,changes});
     }
     editing=null;paint();notify();
    });};
   }
   function paint(){
    needsPaint=false;d.replaceChildren();const close=btn(t('close'),()=>d.close());if(!current){d.append(close,note);return;}
    const doc=current.document,canvas=current.kind==='canvas',editable=current.writable&&!(canvas&&mobile);
    d.setAttribute('aria-label',doc.name);d.append(row(el('h2',doc.name),close),el('small',t(current.owner?'own':'member')+(editable?'':' · '+t('view'))));
    if(editable)d.append(row(btn(t('rename'),()=>edit(null,false,true)),btn(t(canvas?'addCard':'addTask'),()=>edit(null,true))));
    if(canvas)d.append(diagram(doc,n=>edit(n),editable?(node,x,y)=>run(async()=>{
     try{await applyEdit({base:node,id:node.id,canvas:true,changes:{x,y}});}finally{paint();}
    }):null));
    for(const item of canvas?doc.nodes:doc.tasks){
     const b=btn((!canvas&&item.status==='done'?'✓ ':'')+String(item.image?t('photo'):item.title||item.body||item.kind||'…').slice(0,200),()=>edit(item));b.className='item';d.append(b);
    }
    const people=el('details');people.open=peopleOpen;people.ontoggle=()=>{peopleOpen=people.open;};people.append(el('summary',t('members')));
    if(current.owner){
     for(const account of current.editors)people.append(row(el('code',account),btn(t('remove'),()=>run(async()=>{current=await rpc('remove',{id:current.id,account});paint();}))));
     if(current.writable){const input=el('input');input.placeholder=t('id');input.setAttribute('aria-label',t('id'));people.append(row(input,btn(t('invite'),()=>run(async()=>{
      const account=input.value.trim();if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(account))throw Error('SHARE_ACCOUNT');
      current=await rpc('add',{id:current.id,account});paint();
     }))));}
    }else people.append(btn(t('leave'),()=>run(async()=>{await rpc('leave',{id:current.id});d.close();})));
    d.append(people,note);
   }
   const timer=setInterval(poll,3500);paint();d.showModal();activeDialog=d;
  }
  class SharedLibrary extends HTMLElement{
   connectedCallback(){
    if(!this.shadowRoot)this.attachShadow({mode:'open'});this.last='';this.turn=0;
    this.load();this.timer=setInterval(()=>{if(!document.hidden&&!this.loading)this.load();},3500);
   }
   disconnectedCallback(){clearInterval(this.timer);this.turn++;}
   async load(){
    const seq=++this.turn;this.loading=true;
    try{
     const head=await rpc('list',{});if(!this.isConnected||seq!==this.turn)return;
     const kind=this.getAttribute('kind'),resources=head.resources.filter(r=>r.kind===kind);
     const owned=new Set(resources.filter(r=>r.owner).map(r=>r.source));
     const sources=(local(kind)||[]).filter(r=>!owned.has(r.id)&&!r.archived);
     this.resources=resources;
     const signature=JSON.stringify([language?.(),head.account,head.subscribed,resources,sources.map(r=>[r.id,r.name])]);
     if(signature===this.last)return;this.last=signature;
     const root=this.shadowRoot,panel=el('section');panel.className='panel';panel.append(el('h2',t('shared')),row(el('small',t('account')),el('code',head.account)));
     const err=el('p');err.setAttribute('role','status');err.className='error';
     const notify=()=>this.load();
     for(const r of resources){const b=btn(r.name+' · '+t(r.owner?'own':'member'),async()=>{try{await open(await rpc('get',{id:r.id}),notify);}catch(e){err.textContent=message(e);}});b.className='item';panel.append(b);}
     if(head.subscribed&&sources.length && !(mobile&&kind==='canvas')){
      const select=el('select');select.setAttribute('aria-label',t('select'));for(const s of sources){const o=el('option',s.name);o.value=s.id;select.append(o);}
      const share=btn(t('share'),async()=>{share.disabled=true;try{const selected=local(kind).find(r=>r.id===select.value);if(!selected)throw Error('SHARE_INVALID');
       const doc=structuredClone(selected);delete doc.viewport;
       await open(await rpc('create',{kind,document:doc}),notify);await this.load();
      }catch(e){err.textContent=message(e);}finally{share.disabled=false;}});
      panel.append(row(select,share));
     }else if(!head.subscribed&&!resources.length)panel.append(el('small',t('paid')));
     panel.append(err);root.replaceChildren(sheet(),panel);
    }catch(e){if(!this.isConnected||seq!==this.turn)return;this.last='';this.shadowRoot.replaceChildren(sheet(),row(el('span',message(e)),btn(t('retry'),()=>this.load())));}
    finally{if(this.turn===seq)this.loading=false;}
   }
  }
  // Ordinary library cards for an owner's published item open the same resource as
  // the participant's card. Retain the private checkpoint for backup and export.
  document.addEventListener('click',event=>{
   const button=event.target?.closest?.('[data-project-open],[data-canvas-open],[data-alpha="open-project"],[data-alpha="open-board"],[data-project-edit],[data-canvas-rename]');
   if(!button)return;
   const a=button.dataset,kind=a.projectOpen||a.projectEdit||a.alpha==='open-project'?'project':'canvas';
   const source=a.projectOpen||a.projectEdit||a.canvasOpen||a.canvasRename||a.id;
   const library=document.querySelector('path-shared-library[kind="'+kind+'"]');
   if(!library||!source)return;
   const hit=library.resources?.find(r=>r.owner&&r.source===source);
   if(hit){
    event.preventDefault();event.stopImmediatePropagation();
    rpc('get',{id:hit.id}).then(doc=>open(doc,()=>library.load())).catch(e=>{
     const note=library.shadowRoot.querySelector('[role=status]');if(note)note.textContent=message(e);
    });
   }
  },true);
  customElements.define('path-shared-library',SharedLibrary);
 }
 globalThis.PathSharedLibrary={mount};
})();
