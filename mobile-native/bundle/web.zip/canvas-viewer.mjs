const sides = {left:[-1,0], right:[1,0], top:[0,-1], bottom:[0,1]};
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));

// Project collapsed frames just as the desktop Canvas does. Source nodes and links stay intact.
export function boardScene(board, projectNode) {
  const nodes = board.nodes.map(source => {
    const n = projectNode(source);
    return {...n, width:n.width ?? 280, height:n.height ?? 180};
  });
  const owners = new Map();
  const frames = nodes.filter(n => n.collapsed).sort((a,b) => b.width*b.height-a.width*a.height);
  for (const f of frames) {
    if (owners.has(f.id)) continue;
    for (const n of nodes) {
      if (n.id !== f.id && !owners.has(n.id) && n.x >= f.x && n.y >= f.y &&
          n.x+n.width <= f.x+f.width && n.y+n.height <= f.y+f.height) owners.set(n.id, f.id);
    }
  }
  const visible = nodes.filter(n => !owners.has(n.id)).map(n => n.collapsed ? {...n,width:240,height:100} : n);
  const links = [], pairs = new Set();
  for (const edge of board.edges) {
    const from = owners.get(edge.from) ?? edge.from, to = owners.get(edge.to) ?? edge.to;
    const pair = JSON.stringify([from,to]);
    if (from === to || pairs.has(pair)) continue;
    pairs.add(pair);
    links.push({...edge,from,to});
  }
  return {id:board.id,nodes:visible,byId:new Map(visible.map(n=>[n.id,n])),edges:links};
}

function anchor(n, side) {
  const [dx,dy] = sides[side];
  return {x:n.x+(1+dx)*n.width/2, y:n.y+(1+dy)*n.height/2, dx,dy};
}
export function edgeShape(edge, scene) {
  const a=scene.byId.get(edge.from), b=scene.byId.get(edge.to);
  const dx=b.x+b.width/2-a.x-a.width/2, dy=b.y+b.height/2-a.y-a.height/2;
  const defaults = Math.abs(dx)>=Math.abs(dy) ? (dx>=0?['right','left']:['left','right']) : (dy>=0?['bottom','top']:['top','bottom']);
  const p=anchor(a,Object.hasOwn(sides,edge.fromSide)?edge.fromSide:defaults[0]);
  const q=anchor(b,Object.hasOwn(sides,edge.toSide)?edge.toSide:defaults[1]);
  const bend=clamp(Math.hypot(q.x-p.x,q.y-p.y)*.45,40,220);
  return {
    path:`M ${p.x} ${p.y} C ${p.x+p.dx*bend} ${p.y+p.dy*bend}, ${q.x+q.dx*bend} ${q.y+q.dy*bend}, ${q.x} ${q.y}`,
    x:(p.x+q.x)/2, y:(p.y+q.y)/2-8,
  };
}

function boardBounds(nodes) {
  if (!nodes.length) return {left:0,top:0,width:1,height:1};
  const left=Math.min(...nodes.map(n=>n.x)), top=Math.min(...nodes.map(n=>n.y));
  return {left,top,width:Math.max(...nodes.map(n=>n.x+n.width))-left,height:Math.max(...nodes.map(n=>n.y+n.height))-top};
}

// A camera belongs to one open board. Sync can replace its DOM while it is being viewed.
export function createCanvasViewer() {
  let camera = null, detach = null;
  function mount(viewport, scene) {
    detach?.();
    detach = null;
    if (!viewport || !scene) return;
    const world=viewport.querySelector('.canvas-world'), grid=viewport.querySelector('.canvas-grid');
    for (const el of world.querySelectorAll('.canvas-node')) {
      const n=scene.byId.get(el.dataset.id);
      Object.assign(el.style,{left:n.x+'px',top:n.y+'px',width:n.width+'px',height:n.height+'px'});
    }
    const bounds=boardBounds(scene.nodes);
    if (camera?.id !== scene.id) camera={id:scene.id,mode:'initial',width:0,height:0,x:0,y:0,zoom:1};
    let frame=0, gridSize=0, gesture=null, origin=null, suppressClick=false, lastTap=null;
    const contacts=new Map();
    function paint() {
      frame=0;
      const {x,y,zoom}=camera;
      world.style.transform=`translate3d(${x}px,${y}px,0) scale(${zoom})`;
      world.classList.toggle('canvas-low-detail',zoom<.45);
      world.classList.toggle('canvas-tiny-detail',zoom<.28);
      let step=20*zoom;
      // Keep the overview legible while keeping every grid point on a board coordinate.
      while (step<9) step*=2;
      if (step!==gridSize) {gridSize=step;grid.style.backgroundSize=step+'px '+step+'px';}
      const offset=value=>((value%step+step)%step)-step;
      grid.style.transform=`translate3d(${offset(x)}px,${offset(y)}px,0)`;
    }
    function schedule() {if (!frame) frame=requestAnimationFrame(paint);}
    function fitZoom() {
      return Math.max(Number.EPSILON,Math.min(1,Math.max(1,camera.width-32)/bounds.width,Math.max(1,camera.height-32)/bounds.height));
    }
    function frameBoard(mode) {
      const fit=fitZoom();
      let x=bounds.left+bounds.width/2, y=bounds.top+bounds.height/2;
      const zoom=mode==='initial'?Math.max(.75,fit):fit;
      if (zoom>fit && scene.nodes.length) {
        const first=scene.nodes.find(n=>!['group','frame'].includes(n.kind))||scene.nodes[0];
        const halfW=Math.max(1,camera.width-32)/(2*zoom), halfH=Math.max(1,camera.height-32)/(2*zoom);
        if (bounds.width>2*halfW) x=clamp(first.x+first.width/2,bounds.left+halfW,bounds.left+bounds.width-halfW);
        if (bounds.height>2*halfH) y=clamp(first.y+first.height/2,bounds.top+halfH,bounds.top+bounds.height-halfH);
      }
      Object.assign(camera,{mode,zoom,x:camera.width/2-x*zoom,y:camera.height/2-y*zoom});
      schedule();
    }
    function resize() {
      const w=viewport.clientWidth, h=viewport.clientHeight;
      if (!w||!h) return;
      const dw=w-camera.width, dh=h-camera.height;
      camera.width=w;camera.height=h;
      if (camera.mode==='manual') {
        camera.x+=dw/2;camera.y+=dh/2;
        schedule();
      } else frameBoard(camera.mode);
      if (contacts.size) {
        origin=viewport.getBoundingClientRect();
        rebase();
      }
    }
    function transformAt(start, from, to, zoom) {
      // Keep the point that was between the fingers under their moving midpoint.
      const scale=clamp(zoom,Math.min(.15,fitZoom()),3), ratio=scale/start.zoom;
      Object.assign(camera,{mode:'manual',zoom:scale,x:to.x-(from.x-start.x)*ratio,y:to.y-(from.y-start.y)*ratio});
      schedule();
    }
    function sample() {
      const [a,b]=contacts.values();
      if (!b) return {x:a.x-origin.left,y:a.y-origin.top,distance:0};
      return {x:(a.x+b.x)/2-origin.left,y:(a.y+b.y)/2-origin.top,distance:Math.hypot(a.x-b.x,a.y-b.y)};
    }
    function rebase() {
      gesture=contacts.size?{start:sample(),camera:{...camera}}:null;
    }
    viewport.onpointerdown=e=>{
      if (e.button!==0) return;
      if (!contacts.size) {
        origin=viewport.getBoundingClientRect();
        suppressClick=false;
      } else {suppressClick=true;lastTap=null;}
      contacts.set(e.pointerId,{x:e.clientX,y:e.clientY});
      // Preserve the normal click target for a stationary tap on a card.
      (e.target.closest('.canvas-node')||viewport).setPointerCapture(e.pointerId);
      rebase();
    };
    viewport.onpointermove=e=>{
      if (!contacts.has(e.pointerId)) return;
      contacts.set(e.pointerId,{x:e.clientX,y:e.clientY});
      const to=sample(), {start,camera:base}=gesture;
      if (!suppressClick && Math.hypot(to.x-start.x,to.y-start.y)<5) return;
      suppressClick=true;lastTap=null;
      const zoom=start.distance>0?base.zoom*to.distance/start.distance:base.zoom;
      transformAt(base,start,to,zoom);
    };
    function release(e) {
      if (!contacts.has(e.pointerId)) return;
      const cancelled=e.type!=='pointerup';
      if (cancelled) {suppressClick=true;lastTap=null;}
      const blank=!e.target.closest('.canvas-node');
      if (!suppressClick && blank && contacts.size===1 && e.pointerType==='touch') {
        if (lastTap && e.timeStamp-lastTap.time<=330 && Math.hypot(lastTap.x-e.clientX,lastTap.y-e.clientY)<28) {
          frameBoard('fit');lastTap=null;
        } else lastTap={time:e.timeStamp,x:e.clientX,y:e.clientY};
      } else lastTap=null;
      contacts.delete(e.pointerId);
      rebase();
    }
    viewport.onpointerup=viewport.onpointercancel=viewport.onlostpointercapture=release;
    viewport.addEventListener('click',e=>{
      if (suppressClick && e.detail!==0) {e.preventDefault();e.stopPropagation();}
    },true);
    viewport.ondragstart=e=>e.preventDefault();
    viewport.onkeydown=e=>{
      if (e.target!==viewport) return;
      const delta={ArrowLeft:[30,0],ArrowRight:[-30,0],ArrowUp:[0,30],ArrowDown:[0,-30]}[e.key];
      if (delta) {
        camera.mode='manual';camera.x+=delta[0];camera.y+=delta[1];schedule();
      } else if (['+','=','-'].includes(e.key)) {
        const center={x:camera.width/2,y:camera.height/2};
        transformAt(camera,center,center,camera.zoom*(e.key==='-'?1/1.2:1.2));
      } else if (e.key==='0'||e.key==='Home') frameBoard('fit');
      else return;
      e.preventDefault();
    };
    resize();
    const observer=new ResizeObserver(resize);
    observer.observe(viewport);
    detach=()=>{observer.disconnect();cancelAnimationFrame(frame);contacts.clear();};
  }
  return {mount, reset(){detach?.();detach=null;camera=null;}};
}
