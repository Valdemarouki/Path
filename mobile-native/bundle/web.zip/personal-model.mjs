import {validateEventRecord,validateHabitRecord,validateHomeTaskRecord} from './model.mjs';
import {tasksForDate} from './task-selectors.mjs';
import {collections} from './sync-merge.mjs';
export {collections,equal,reconcile} from './sync-merge.mjs';
const validators={events:validateEventRecord,habits:validateHabitRecord,homeTasks:validateHomeTaskRecord};
export function apply(state,payload){
 const prior=state.canvases||[],readOnly={},seen=new Set();
 for(const key of collections){
  if(!Array.isArray(payload[key]))throw Error('INVALID_SNAPSHOT');
  const rows=[];
  for(const row of payload[key]){
   if(validators[key]){
    try{validators[key](row);if(seen.has(row.id))throw Error('duplicate');seen.add(row.id);}
    catch{readOnly[key+':'+row.id]=row;continue;}
   }
   const viewport=key==='canvases'&&prior.find(c=>c.id===row.id)?.viewport;
   rows.push(viewport?{...row,viewport}:row);
  }
  if(key==='notes'){
   const journals=(state.notes||[]).filter(n=>n.kind==='journal');
   if(journals.some(j=>rows.some(n=>n.id===j.id)))throw Error('INVALID_SNAPSHOT');
   rows.push(...journals);
  }
  state[key]=structuredClone(rows);
 }
 state.workspaceReadOnly=structuredClone(readOnly);
 state.exercisePreferences=structuredClone(payload.exercisePreferences);
 for(const [day,id] of Object.entries(state.mainTasks||{}))if(!tasksForDate(state,day,{includeArchived:true}).some(t=>t.id===id))delete state.mainTasks[day];
}
export function projection(state,base){
 const result={schema:3,exercisePreferences:state.exercisePreferences||{}};
 for(const key of collections){
  if(key==='canvases'){result.canvases=base.canvases;continue;}
  const rows=new Map((state[key]||[]).filter(r=>key!=='notes'||r.kind==='note').map(r=>[r.id,r]));
  for(const [name,row] of Object.entries(state.workspaceReadOnly||{}))if(name.startsWith(key+':'))rows.set(row.id,row);
  result[key]=[];
  for(const row of base[key])if(rows.has(row.id)){result[key].push(rows.get(row.id));rows.delete(row.id);}
  result[key].push(...rows.values());
 }
 return result;
}
